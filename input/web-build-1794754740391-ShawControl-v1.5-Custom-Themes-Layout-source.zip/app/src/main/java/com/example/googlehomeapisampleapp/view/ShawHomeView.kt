package com.example.googlehomeapisampleapp.view

import android.content.Intent
import android.os.SystemClock
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.DevicesOther
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.googlehomeapisampleapp.AccountSwitchProxyActivity
import com.example.googlehomeapisampleapp.viewmodel.HomeAppViewModel
import com.example.googlehomeapisampleapp.viewmodel.devices.DeviceViewModel
import com.google.home.matter.standard.OnOff
import com.google.home.matter.standard.LevelControl
import com.google.home.matter.standard.LevelControlTrait
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** Compact dashboard built on the already-working Google Home permission/control flow. */
@Composable
fun ShawHomeView(vm: HomeAppViewModel) {
    val signedIn by vm.homeApp.permissionsManager.isSignedIn.collectAsState()
    val structure by vm.selectedStructureVM.collectAsState()
    val selectedDevice by vm.selectedDeviceVM.collectAsState()
    val context = LocalContext.current
    val tilePrefs = remember(context) { ShawTilePreferences(context.applicationContext) }
    val appearancePrefs = remember(context) { ShawAppearancePreferences(context.applicationContext) }
    val palette = rememberShawPalette(appearancePrefs)
    val scope = rememberCoroutineScope()
    var settingsOpen by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.navigateToProxyActivity.collect {
            val intent = Intent(context, AccountSwitchProxyActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            context.startActivity(intent)
        }
    }

    CompositionLocalProvider(LocalShawPalette provides palette) {
        val colorScheme = if (palette.isDark) darkColorScheme(
            primary = palette.primary, onPrimary = palette.onPrimary,
            background = palette.background, onBackground = palette.ink,
            surface = palette.surface, onSurface = palette.ink,
            surfaceVariant = palette.activeTile, onSurfaceVariant = palette.ink,
            outline = palette.hairline
        ) else lightColorScheme(
            primary = palette.primary, onPrimary = palette.onPrimary,
            background = palette.background, onBackground = palette.ink,
            surface = palette.surface, onSurface = palette.ink,
            surfaceVariant = palette.activeTile, onSurfaceVariant = palette.ink,
            outline = palette.hairline
        )
        MaterialTheme(colorScheme = colorScheme) {
            when {
                !signedIn -> ShawConnectScreen(
                    onConnect = { vm.signInWithGoogleAccount(context) },
                    onGrantAccess = { vm.homeApp.permissionsManager.requestPermissions() }
                )
                selectedDevice != null -> {
                    com.example.googlehomeapisampleapp.view.devices.DeviceView(vm)
                }
                else -> {
                    val devices = structure?.deviceVMs?.collectAsState()?.value.orEmpty()
                    Scaffold(
                        containerColor = palette.background,
                        bottomBar = {
                            NavigationBar(containerColor = palette.surface, tonalElevation = 0.dp) {
                                NavigationBarItem(
                                    selected = !settingsOpen,
                                    onClick = { settingsOpen = false },
                                    icon = { Icon(Icons.Outlined.Home, contentDescription = null) },
                                    label = { Text("Home") }
                                )
                                NavigationBarItem(
                                    selected = settingsOpen,
                                    onClick = { settingsOpen = true },
                                    icon = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                                    label = { Text("Settings") }
                                )
                            }
                        }
                    ) { insets ->
                        Box(Modifier.fillMaxSize().padding(insets)) {
                            if (settingsOpen) {
                                ShawSettingsScreen(
                                    devices = devices,
                                    tilePrefs = tilePrefs,
                                    appearancePrefs = appearancePrefs,
                                    onManageAccess = {
                                        vm.homeApp.permissionsManager.requestPermissions(isForceRefresh = true)
                                    }
                                )
                            } else {
                                ShawDashboard(
                                    homeName = structure?.name ?: "Your home",
                                    isLoading = structure == null,
                                    devices = tilePrefs.sort(devices).filter { tilePrefs.isVisible(it.id) },
                                    tilePrefs = tilePrefs,
                                    onCustomise = { settingsOpen = true },
                                    onDetails = { device -> scope.launch { vm.selectedDeviceVM.emit(device) } }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShawConnectScreen(onConnect: () -> Unit, onGrantAccess: () -> Unit) {
    val colors = LocalShawPalette.current
    Column(
        modifier = Modifier.fillMaxSize().background(colors.background).padding(28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("SHAW CONTROL", color = colors.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(12.dp))
        Text("Home, made simple.", fontSize = 34.sp, fontWeight = FontWeight.SemiBold, color = colors.ink)
        Spacer(Modifier.height(10.dp))
        Text("Your devices, all in one place.", color = colors.muted, fontSize = 16.sp)
        Spacer(Modifier.height(38.dp))
        Button(onClick = onConnect, modifier = Modifier.fillMaxWidth().height(55.dp), shape = RoundedCornerShape(18.dp)) {
            Text("Connect Google Home", fontSize = 16.sp)
        }
        TextButton(onClick = onGrantAccess, modifier = Modifier.fillMaxWidth()) {
            Text("Already signed in? Grant access")
        }
        Spacer(Modifier.height(8.dp))
        Text("Google handles sign-in and device permissions. Your Google password isn't shared with Shaw Control.",
            color = colors.muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun ShawDashboard(
    homeName: String,
    isLoading: Boolean,
    devices: List<DeviceViewModel>,
    tilePrefs: ShawTilePreferences,
    onCustomise: () -> Unit,
    onDetails: (DeviceViewModel) -> Unit
) {
    val colors = LocalShawPalette.current
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 21.dp, end = 21.dp, top = 20.dp, bottom = 10.dp)) {
            Text("SHAW CONTROL", color = colors.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(9.dp))
            Text(homeName, color = colors.ink, fontWeight = FontWeight.SemiBold, fontSize = 30.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            Text("Tap any tile to control it", color = colors.muted, fontSize = 14.sp)
        }
        when {
            isLoading -> {
                Row(Modifier.padding(26.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(14.dp))
                    Text("Connecting to Google Home…", color = colors.muted)
                }
            }
            devices.isEmpty() -> {
                Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.DevicesOther, contentDescription = null,
                        tint = colors.offIcon, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("No tiles on your Home", color = colors.ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("Choose which Google Home devices to show.", color = colors.muted, fontSize = 14.sp)
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = onCustomise) { Text("Choose tiles") }
                }
            }
            else -> {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
                ) {
                    items(
                        items = devices,
                        key = { it.id },
                        span = { device -> GridItemSpan(if (tilePrefs.sizeFor(device.id) == "Large") 2 else 1) }
                    ) { device ->
                        ShawDeviceTile(device, size = tilePrefs.sizeFor(device.id)) { onDetails(device) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShawSettingsScreen(
    devices: List<DeviceViewModel>,
    tilePrefs: ShawTilePreferences,
    appearancePrefs: ShawAppearancePreferences,
    onManageAccess: () -> Unit
) {
    val colors = LocalShawPalette.current
    val sorted = tilePrefs.sort(devices)
    val visibleCount = devices.count { tilePrefs.isVisible(it.id) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 19.dp)) {
        Spacer(Modifier.height(20.dp))
        Text("SHAW CONTROL", color = colors.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(9.dp))
        Text("Settings", fontSize = 30.sp, color = colors.ink, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(7.dp))
        Text("Your home, your layout.", color = colors.muted, fontSize = 14.sp)
        Spacer(Modifier.height(22.dp))
        Surface(shape = RoundedCornerShape(22.dp), color = colors.surface) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("Appearance", color = colors.ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(15.dp))
                ShawChoiceRow("Display mode", listOf("System", "Light", "Dark"), appearancePrefs.themeMode, appearancePrefs::setTheme)
                Spacer(Modifier.height(13.dp))
                ShawChoiceRow("Accent colour", listOf("Blue", "Violet", "Teal", "Green", "Coral"), appearancePrefs.accentName, appearancePrefs::setAccent)
                Spacer(Modifier.height(13.dp))
                ShawChoiceRow("Background", listOf("Default", "Slate", "Sand", "Sage", "Rose"), appearancePrefs.backgroundName, appearancePrefs::setBackground)
            }
        }
        Spacer(Modifier.height(14.dp))
        Surface(shape = RoundedCornerShape(22.dp), color = colors.surface) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Home tiles", color = colors.ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                        Text("$visibleCount of ${devices.size} showing", color = colors.muted, fontSize = 12.sp)
                    }
                    TextButton(onClick = tilePrefs::showAll) { Text("Show all") }
                }
                Spacer(Modifier.height(6.dp))
                Text("Set a size and move each tile up or down. Large tiles fill both columns.",
                    color = colors.muted, fontSize = 12.sp, lineHeight = 17.sp)
                Spacer(Modifier.height(12.dp))
                if (sorted.isEmpty()) {
                    Text("Devices will appear after Google Home finishes loading.", color = colors.muted,
                        modifier = Modifier.padding(vertical = 12.dp))
                }
                sorted.forEachIndexed { index, device ->
                    key(device.id) {
                        if (index > 0) HorizontalDivider(color = colors.hairline)
                        ShawTileSettingRow(
                            device = device,
                            visible = tilePrefs.isVisible(device.id),
                            size = tilePrefs.sizeFor(device.id),
                            canMoveUp = index > 0,
                            canMoveDown = index < sorted.lastIndex,
                            onChange = { tilePrefs.setVisible(device.id, it) },
                            onSize = { tilePrefs.setSize(device.id, it) },
                            onMoveUp = { tilePrefs.move(device.id, -1, devices) },
                            onMoveDown = { tilePrefs.move(device.id, 1, devices) }
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Changes save automatically on this phone. Hidden devices remain connected in Google Home.",
            color = colors.muted, fontSize = 12.sp, lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 7.dp))
        Spacer(Modifier.height(16.dp))
        TextButton(onClick = onManageAccess) { Text("Manage Google Home access") }
        Spacer(Modifier.height(26.dp))
    }
}

@Composable
private fun ShawChoiceRow(
    label: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    val colors = LocalShawPalette.current
    Text(label, color = colors.muted, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    Spacer(Modifier.height(6.dp))
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { option ->
            FilterChip(selected = option == selected, onClick = { onSelect(option) },
                label = { Text(option, maxLines = 1) })
        }
    }
}

@Composable
private fun ShawTileSettingRow(
    device: DeviceViewModel,
    visible: Boolean,
    size: String,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onChange: (Boolean) -> Unit,
    onSize: (String) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit
) {
    val colors = LocalShawPalette.current
    val name by device.name.collectAsState()
    Column(Modifier.fillMaxWidth().padding(vertical = 9.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (looksLikeLight(name)) Icons.Rounded.Lightbulb else Icons.Rounded.Power,
                contentDescription = null, tint = colors.muted, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Text(name, color = colors.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).clickable { onChange(!visible) })
            Checkbox(checked = visible, onCheckedChange = onChange)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Small", "Medium", "Large").forEach { option ->
                    FilterChip(selected = size == option, onClick = { onSize(option) },
                        label = { Text(option, fontSize = 11.sp) })
                }
            }
            IconButton(onClick = onMoveUp, enabled = canMoveUp) {
                Icon(Icons.Rounded.KeyboardArrowUp, contentDescription = "Move $name up", tint = colors.muted)
            }
            IconButton(onClick = onMoveDown, enabled = canMoveDown) {
                Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Move $name down", tint = colors.muted)
            }
        }
    }
}

private fun looksLikeLight(name: String): Boolean =
    name.contains("light", ignoreCase = true) ||
        name.contains("lamp", ignoreCase = true) ||
        name.contains("bulb", ignoreCase = true)

/**
 * The Home API may report stale cloud state after sending a real command.
 * The displayed requested state and Google's reported state remain separate.
 * Queued reverse taps are dispatched in order, never automatically retried.
 */
@Composable
private fun ShawDeviceTile(vm: DeviceViewModel, size: String, onOpen: () -> Unit) {
    val colors = LocalShawPalette.current
    val name by vm.name.collectAsState()
    val status by vm.status.collectAsState()
    val traits by vm.traits.collectAsState()
    val powerReading by vm.powerReading.collectAsState()
    val brightnessReading by vm.brightnessReading.collectAsState()
    val scope = rememberCoroutineScope()

    val onOff = traits.filterIsInstance<OnOff>().firstOrNull()
    val level = traits.filterIsInstance<LevelControl>().firstOrNull()
    val reportedOn = powerReading.value
    val reportedLevel = brightnessReading.value

    // The command's *requested* state is independent of Google Home's last cached report.
    // It is NOT described as verified until the trait stream reports a NEW matching state.
    var requestedOn by remember(vm.id) { mutableStateOf<Boolean?>(null) }
    var revisionBeforeCommand by remember(vm.id) { mutableLongStateOf(0L) }
    var sendingPower by remember(vm.id) { mutableStateOf(false) }
    // Last explicit user action while a previous API command is in flight.
    // Queuing the reverse action avoids sending two racing network commands.
    var queuedPower by remember(vm.id) { mutableStateOf<Boolean?>(null) }
    var commandNumber by remember(vm.id) { mutableIntStateOf(0) }
    var lastPowerApiDurationMs by remember(vm.id) { mutableStateOf<Long?>(null) }
    var powerMessage by remember(vm.id) { mutableStateOf<String?>(null) }
    var confirmPcOff by remember(vm.id) { mutableStateOf(false) }
    var syncingState by remember(vm.id) { mutableStateOf(false) }

    var brightness by remember(vm.id) { mutableFloatStateOf(reportedLevel?.toFloat() ?: 0f) }
    var editingBrightness by remember(vm.id) { mutableStateOf(false) }
    var sendingBrightness by remember(vm.id) { mutableStateOf(false) }
    var requestedLevel by remember(vm.id) { mutableStateOf<Int?>(null) }
    var brightnessRevisionBeforeCommand by remember(vm.id) { mutableLongStateOf(0L) }
    var brightnessCommandNumber by remember(vm.id) { mutableIntStateOf(0) }
    var brightnessMessage by remember(vm.id) { mutableStateOf<String?>(null) }

    val effectiveOn = requestedOn ?: reportedOn ?: false
    val isPcPlug = remember(name) { Regex("(?i)\\b(pc|computer)\\b").containsMatchIn(name) }

    // Only a fresh transition to the requested state counts as confirmation. A cached
    // Google OFF value cannot 'confirm' a freshly requested OFF if it was already OFF.
    LaunchedEffect(powerReading, requestedOn) {
        if (queuedPower == null && ShawStateReconciler.isConfirmed(
                requestedOn, revisionBeforeCommand, powerReading.value, powerReading.revision
            )) {
            Log.i("ShawControl.Commands", "Power state confirmed by trait flow for ${vm.id}")
            requestedOn = null
            powerMessage = null
        }
    }

    // Do not flag a successful command as broken just because the cloud trait cache
    // is late. Only transport errors/timeouts are warnings; never re-send power.
    var busyForAWhile by remember(vm.id) { mutableStateOf(false) }
    LaunchedEffect(sendingPower) {
        busyForAWhile = false
        if (sendingPower) {
            delay(1200)
            busyForAWhile = sendingPower
        }
    }

    LaunchedEffect(brightnessReading, requestedLevel) {
        if (ShawStateReconciler.isConfirmedWithinOne(
                requestedLevel, brightnessRevisionBeforeCommand,
                reportedLevel, brightnessReading.revision
            )) {
            requestedLevel = null
            brightnessMessage = null
        }
        if (!editingBrightness && requestedLevel == null && reportedLevel != null) {
            brightness = reportedLevel.toFloat()
        }
    }
    // Don't warn merely because the Google Home cached brightness value is late.
    // Only report an actual API timeout or exception below.

    fun refreshState() {
        if (syncingState || sendingPower || sendingBrightness) return
        syncingState = true
        scope.launch {
            try {
                // Force reads may be throttled; keep them manual and bounded.
                val completed = withTimeoutOrNull(4500) {
                    if (onOff != null) onOff.forceRead()
                    if (level != null) level.forceRead()
                    true
                } ?: false
                if (!completed) {
                    powerMessage = "State refresh timed out. Google's last report may be old."
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                powerMessage = "State refresh failed: ${e.message?.take(100) ?: "Device unavailable"}"
            } finally {
                syncingState = false
            }
        }
    }

    fun setPower(next: Boolean, dispatchQueued: Boolean = false) {
        if (onOff == null || (!dispatchQueued && effectiveOn == next)) return
        if (sendingPower) {
            // This is a NEW user tap, not an automated retry. Queue just the latest
            // requested state until the in-flight command finishes, preserving order.
            queuedPower = next
            requestedOn = next
            powerMessage = null
            Log.i("ShawControl.Commands", "Queued user reversal for ${vm.id}: $next")
            return
        }
        // Snapshot the revision BEFORE beginning a new request.
        revisionBeforeCommand = powerReading.revision
        requestedOn = next
        commandNumber++
        sendingPower = true
        powerMessage = null
        val currentCommand = commandNumber
        lastPowerApiDurationMs = null
        val startedAt = SystemClock.elapsedRealtime()
        Log.i("ShawControl.Commands", "Power request for ${vm.id}: $next, lastReported=$reportedOn")
        scope.launch {
            try {
                // A hanging cloud RPC must not block the switch forever.
                val accepted = withTimeoutOrNull(8000) {
                    if (next) onOff.on() else onOff.off()
                    true
                } ?: false
                if (commandNumber == currentCommand) {
                    if (!accepted) {
                        powerMessage = "Google took too long to respond; the physical state is " +
                            "uncertain. No command was retried."
                        Log.w("ShawControl.Commands", "Power command response timed out for ${vm.id}")
                    } else {
                        Log.i("ShawControl.Commands", "Power command response for ${vm.id} after ${SystemClock.elapsedRealtime() - startedAt} ms")
                        // If a reverse command is queued, skip this read; the queued
                        // command will run next and eventually read the final state.
                        if (queuedPower != null) return@launch
                        // Don't make the entire card wait for forceRead(). Trigger exactly
                        // one low-priority targeted read; live state comes from the flow.
                        scope.launch {
                            delay(500)
                            try {
                                withTimeoutOrNull(3500) { onOff.forceRead() }
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                Log.w("ShawControl.Commands", "Post-command read unavailable", e)
                            }
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("ShawControl.Commands", "Power command exception for ${vm.id}", e)
                if (commandNumber == currentCommand) {
                    powerMessage = "Google reported an error: " +
                        "${e.message?.take(130) ?: "Device unavailable"}. Check the light's real state."
                }
            } finally {
                // Crucial: release the control when the COMMAND returns, not when
                // Google's delayed trait cache catches up (which may never happen).
                lastPowerApiDurationMs = SystemClock.elapsedRealtime() - startedAt
                sendingPower = false
                // Dispatch the user's latest queued instruction once, in sequence.
                // Never auto-repeat the old ON/OFF instruction.
                val queued = queuedPower
                queuedPower = null
                if (queued != null && queued != next) {
                    setPower(queued, dispatchQueued = true)
                }
            }
        }
    }

    var showControls by remember(vm.id) { mutableStateOf(false) }
    val tileOn = effectiveOn && onOff != null
    val cardColor = if (tileOn) colors.activeTile else colors.surface
    val contentColor = if (tileOn) colors.activeText else colors.ink
    val subtitle = when {
        onOff == null -> status.takeIf { it.isNotBlank() && it != "--" } ?: "View details"
        busyForAWhile && sendingPower -> "Changing…"
        reportedOn == null && requestedOn == null -> "Connecting…"
        tileOn -> "On"
        else -> "Off"
    }
    val icon = when {
        level != null || looksLikeLight(name) -> Icons.Rounded.Lightbulb
        onOff != null -> Icons.Rounded.Power
        else -> Icons.Rounded.DevicesOther
    }

    Column(Modifier.fillMaxWidth()) {
        Surface(
            onClick = {
                if (onOff == null) {
                    onOpen()
                } else {
                    val next = !effectiveOn
                    if (!next && isPcPlug) confirmPcOff = true else setPower(next)
                }
            },
            shape = RoundedCornerShape(25.dp),
            color = cardColor,
            modifier = Modifier.fillMaxWidth().height(when (size) {
                "Small" -> 125.dp
                "Large" -> 183.dp
                else -> 162.dp
            }),
            shadowElevation = 0.dp
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(if (size == "Small") 12.dp else 16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(if (size == "Small") 36.dp else 44.dp).background(
                            if (tileOn) colors.activeIconBackground else colors.iconBackground,
                            shape = CircleShape
                        ), contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = if (tileOn) colors.activeIcon else colors.offIcon,
                            modifier = Modifier.size(if (size == "Small") 21.dp else 24.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    // Keep controls reachable even while Google is processing a command.
                    IconButton(
                        onClick = { showControls = !showControls },
                        modifier = Modifier.size(33.dp)
                    ) {
                        Icon(Icons.Outlined.MoreHoriz, contentDescription = "More controls for $name",
                            tint = if (tileOn) colors.activeIcon else colors.muted)
                    }
                }
                Column {
                    Text(name, color = contentColor, fontWeight = FontWeight.SemiBold,
                        fontSize = if (size == "Small") 14.sp else 16.sp,
                        lineHeight = if (size == "Small") 17.sp else 19.sp, maxLines = 2,
                        overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(if (size == "Small") 3.dp else 7.dp))
                    Text(subtitle, color = if (tileOn) colors.activeIcon else colors.muted, fontSize = 12.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        if (showControls || powerMessage != null || brightnessMessage != null) {
            Spacer(Modifier.height(8.dp))
            Surface(shape = RoundedCornerShape(20.dp), color = colors.surface, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(13.dp)) {
                    if (powerMessage != null) {
                        Text(powerMessage ?: "", fontSize = 11.sp, lineHeight = 15.sp, color = colors.warning)
                        Spacer(Modifier.height(8.dp))
                    }
                    if (showControls) {
                        if (level != null && reportedLevel != null) {
                            Text(
                                "Brightness ${(brightness * 100f / 254f).toInt()}%" +
                                    (if (sendingBrightness) " · changing" else ""),
                                color = colors.ink, fontSize = 12.sp, fontWeight = FontWeight.Medium
                            )
                            Slider(
                                value = brightness.coerceIn(0f, 254f),
                                onValueChange = { brightness = it; editingBrightness = true },
                                valueRange = 0f..254f,
                                enabled = !sendingBrightness,
                                onValueChangeFinished = {
                                    editingBrightness = false
                                    val chosen = brightness.toInt().coerceIn(0, 254)
                                    val oldDisplayed = requestedLevel ?: reportedLevel
                                    if (!sendingBrightness && chosen != oldDisplayed) {
                                        sendingBrightness = true
                                        brightnessRevisionBeforeCommand = brightnessReading.revision
                                        requestedLevel = chosen
                                        brightnessCommandNumber++
                                        brightnessMessage = null
                                        val command = brightnessCommandNumber
                                        scope.launch {
                                            try {
                                                val accepted = withTimeoutOrNull(8000) {
                                                    level.moveToLevelWithOnOff(
                                                        level = chosen.toUByte(), transitionTime = null,
                                                        optionsMask = LevelControlTrait.OptionsBitmap(),
                                                        optionsOverride = LevelControlTrait.OptionsBitmap()
                                                    )
                                                    true
                                                } ?: false
                                                if (!accepted && command == brightnessCommandNumber) {
                                                    brightnessMessage = "Google didn't confirm brightness yet."
                                                }
                                                if (accepted) {
                                                    scope.launch {
                                                        delay(500)
                                                        try {
                                                            withTimeoutOrNull(3500) { level.forceRead() }
                                                        } catch (e: CancellationException) { throw e }
                                                        catch (e: Exception) {
                                                            Log.w("ShawControl.Commands", "Brightness read unavailable", e)
                                                        }
                                                    }
                                                }
                                            } catch (e: CancellationException) { throw e }
                                            catch (e: Exception) {
                                                brightnessMessage = "Brightness failed: ${e.message?.take(80) ?: "Unavailable"}"
                                            } finally {
                                                sendingBrightness = false
                                            }
                                        }
                                    }
                                }
                            )
                        }
                        if (requestedOn != null && reportedOn != requestedOn) {
                            Text("Google's cached state may be behind. Tap Sync for a new reading.",
                                color = colors.muted, fontSize = 11.sp)
                        }
                        if (lastPowerApiDurationMs != null) {
                            Text("API: ${lastPowerApiDurationMs} ms", color = colors.muted, fontSize = 11.sp)
                        }
                        TextButton(onClick = { refreshState() },
                            enabled = !syncingState && !sendingPower && !sendingBrightness,
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Icon(Icons.Outlined.Refresh, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(if (syncingState) "Syncing" else "Sync state", fontSize = 11.sp)
                        }
                        TextButton(onClick = onOpen, contentPadding = PaddingValues(0.dp)) {
                            Text("Device details", fontSize = 11.sp)
                        }
                    }
                    if (brightnessMessage != null) {
                        Text(brightnessMessage ?: "", color = colors.warning, fontSize = 11.sp)
                    }
                }
            }
        }
    }

    if (confirmPcOff) {
        AlertDialog(
            onDismissRequest = { confirmPcOff = false },
            title = { Text("Turn off PC plug?") },
            text = { Text("This cuts electricity immediately. Shut Windows down first. Shaw Control won't retry the command automatically.") },
            confirmButton = {
                TextButton(onClick = { confirmPcOff = false; setPower(false) }) { Text("Switch off") }
            },
            dismissButton = { TextButton(onClick = { confirmPcOff = false }) { Text("Cancel") } }
        )
    }
}
