package com.example.googlehomeapisampleapp.view

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver

/** Choices are stored locally; they do not change Google Home permissions or devices. */
internal class ShawAppearancePreferences(context: Context) {
    private val store = context.applicationContext.getSharedPreferences("shaw_dashboard", Context.MODE_PRIVATE)

    var themeMode by mutableStateOf(store.getString("appearance_theme_v1", "System") ?: "System")
        private set
    var accentName by mutableStateOf(store.getString("appearance_accent_v1", "Blue") ?: "Blue")
        private set
    var backgroundName by mutableStateOf(store.getString("appearance_background_v1", "Default") ?: "Default")
        private set

    fun setTheme(value: String) {
        if (value !in listOf("System", "Light", "Dark")) return
        themeMode = value
        store.edit().putString("appearance_theme_v1", value).apply()
    }
    fun setAccent(value: String) {
        if (value !in listOf("Blue", "Violet", "Teal", "Green", "Coral")) return
        accentName = value
        store.edit().putString("appearance_accent_v1", value).apply()
    }
    fun setBackground(value: String) {
        if (value !in listOf("Default", "Slate", "Sand", "Sage", "Rose")) return
        backgroundName = value
        store.edit().putString("appearance_background_v1", value).apply()
    }
}

internal data class ShawPalette(
    val isDark: Boolean,
    val background: Color,
    val surface: Color,
    val ink: Color,
    val muted: Color,
    val primary: Color,
    val onPrimary: Color,
    val activeTile: Color,
    val activeText: Color,
    val activeIcon: Color,
    val offIcon: Color,
    val hairline: Color,
    val warning: Color,
    val iconBackground: Color,
    val activeIconBackground: Color
)

internal val LocalShawPalette = staticCompositionLocalOf { makeShawPalette(false, "Blue", "Default") }

@Composable
internal fun rememberShawPalette(prefs: ShawAppearancePreferences): ShawPalette {
    val systemDark = isSystemInDarkTheme()
    val dark = when (prefs.themeMode) {
        "Dark" -> true
        "Light" -> false
        else -> systemDark
    }
    return makeShawPalette(dark, prefs.accentName, prefs.backgroundName)
}

private fun makeShawPalette(dark: Boolean, accentName: String, backgroundName: String): ShawPalette {
    val accent = when (accentName) {
        "Violet" -> if (dark) Color(0xFFBFA4FF) else Color(0xFF6E47B2)
        "Teal" -> if (dark) Color(0xFF72D7D1) else Color(0xFF137E7D)
        "Green" -> if (dark) Color(0xFFA1DE93) else Color(0xFF347E47)
        "Coral" -> if (dark) Color(0xFFFFB39C) else Color(0xFFAE533F)
        else -> if (dark) Color(0xFF9EC7FF) else Color(0xFF2A5EA8)
    }
    val bg = when (backgroundName) {
        "Slate" -> if (dark) Color(0xFF171F30) else Color(0xFFE8ECF3)
        "Sand" -> if (dark) Color(0xFF28231F) else Color(0xFFFAF2E7)
        "Sage" -> if (dark) Color(0xFF18261F) else Color(0xFFEAF3E9)
        "Rose" -> if (dark) Color(0xFF2A2029) else Color(0xFFF9EEF3)
        else -> if (dark) Color(0xFF101620) else Color(0xFFF5F7FB)
    }
    return if (dark) ShawPalette(
        isDark = true,
        background = bg,
        surface = Color(0xFF222B3B),
        ink = Color(0xFFF5F7FC),
        muted = Color(0xFFADBBD0),
        primary = accent,
        onPrimary = Color(0xFF111823),
        activeTile = accent.copy(alpha = 0.22f).compositeOver(Color(0xFF20283A)),
        activeText = Color(0xFFF8FAFF),
        activeIcon = accent,
        offIcon = Color(0xFFBAC5D7),
        hairline = Color(0xFF3D4759),
        warning = Color(0xFFFFB5A2),
        iconBackground = Color(0xFF334056),
        activeIconBackground = accent.copy(alpha = 0.20f).compositeOver(Color(0xFF354052))
    ) else ShawPalette(
        isDark = false,
        background = bg,
        surface = Color.White,
        ink = Color(0xFF202C42),
        muted = Color(0xFF63718A),
        primary = accent,
        onPrimary = Color.White,
        activeTile = accent.copy(alpha = 0.14f).compositeOver(Color.White),
        activeText = Color(0xFF202C42),
        activeIcon = accent,
        offIcon = Color(0xFF667891),
        hairline = Color(0xFFE6EAF1),
        warning = Color(0xFFB34C38),
        iconBackground = Color(0xFFF1F3F7),
        activeIconBackground = accent.copy(alpha = 0.16f).compositeOver(Color.White)
    )
}
