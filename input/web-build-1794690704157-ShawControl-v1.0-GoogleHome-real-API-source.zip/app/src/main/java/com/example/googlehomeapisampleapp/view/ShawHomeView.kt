package com.example.googlehomeapisampleapp.view

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.googlehomeapisampleapp.AccountSwitchProxyActivity
import com.example.googlehomeapisampleapp.viewmodel.HomeAppViewModel
import com.example.googlehomeapisampleapp.viewmodel.devices.DeviceViewModel
import com.google.home.matter.standard.OnOff
import com.google.home.matter.standard.LevelControl
import com.google.home.matter.standard.LevelControlTrait
import kotlinx.coroutines.launch

private val Night = Color(0xFF0B1422)
private val Panel = Color(0xFF17253A)
private val Sky = Color(0xFF72B6FF)
private val Pale = Color(0xFFB0C1D7)

@Composable
fun ShawHomeView(vm: HomeAppViewModel) {
    val signedIn by vm.homeApp.permissionsManager.isSignedIn.collectAsState()
    val structure by vm.selectedStructureVM.collectAsState()
    val selectedDevice by vm.selectedDeviceVM.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        vm.navigateToProxyActivity.collect {
            val intent = Intent(context, AccountSwitchProxyActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            context.startActivity(intent)
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Sky, background = Night, surface = Panel)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Night) {
            if (!signedIn) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(26.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Shaw Control", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(10.dp))
                    Text("Your home, one connection.", fontSize = 16.sp, color = Pale)
                    Spacer(Modifier.height(40.dp))
                    Button(
                        onClick = { vm.signInWithGoogleAccount(context) },
                        modifier = Modifier.fillMaxWidth().height(58.dp)
                    ) { Text("Connect Google Home", fontSize = 17.sp) }
                    Spacer(Modifier.height(12.dp))
                    TextButton(onClick = { vm.homeApp.permissionsManager.requestPermissions() }) {
                        Text("Already signed in? Grant access")
                    }
                    Spacer(Modifier.height(15.dp))
                    Text("Google will ask which home and devices to share. Your password stays with Google.",
                        fontSize = 13.sp, color = Pale)
                }
            } else if (selectedDevice != null) {
                // Retain Google's real device-detail controls, including supported traits.
                com.example.googlehomeapisampleapp.view.devices.DeviceView(vm)
            } else {
                val selectedRooms = structure?.roomVMs?.collectAsState()?.value.orEmpty()
                val unassigned = structure?.deviceVMsWithoutRooms?.collectAsState()?.value.orEmpty()
                Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    Spacer(Modifier.height(37.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Shaw Control", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            Text(structure?.name ?: "Loading your Google Home…", color = Pale, fontSize = 14.sp)
                        }
                        TextButton(onClick = { vm.homeApp.permissionsManager.requestPermissions(isForceRefresh = true) }) {
                            Text("Access")
                        }
                    }
                    Spacer(Modifier.height(19.dp))
                    Column(Modifier.verticalScroll(rememberScrollState()).fillMaxWidth()) {
                        if (structure == null) {
                            Text("Your home is loading. Check your Google Home permissions if no devices appear.", color = Pale)
                        }
                        selectedRooms.forEach { room ->
                            Text(room.name.collectAsState().value, color = Pale,
                                modifier = Modifier.padding(top = 17.dp, bottom = 7.dp, start = 4.dp))
                            room.deviceVMs.collectAsState().value.forEach { device ->
                                ShawDeviceCard(device) { scope.launch { vm.selectedDeviceVM.emit(device) } }
                            }
                        }
                        if (unassigned.isNotEmpty()) {
                            Text("Other devices", color = Pale, modifier = Modifier.padding(top = 17.dp, bottom = 7.dp))
                            unassigned.forEach { device ->
                                ShawDeviceCard(device) { scope.launch { vm.selectedDeviceVM.emit(device) } }
                            }
                        }
                        Spacer(Modifier.height(25.dp))
                        Text("Controls are synced through Google's Home APIs. Some device types may not expose every feature.",
                            fontSize = 12.sp, color = Pale)
                        Spacer(Modifier.height(30.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ShawDeviceCard(vm: DeviceViewModel, onOpen: () -> Unit) {
    val name by vm.name.collectAsState()
    val status by vm.status.collectAsState()
    val traits by vm.traits.collectAsState()
    val scope = rememberCoroutineScope()
    val onOff = traits.filterIsInstance<OnOff>().firstOrNull()
    val level = traits.filterIsInstance<LevelControl>().firstOrNull()
    var busy by remember(vm.id) { mutableStateOf(false) }
    var error by remember(vm.id) { mutableStateOf<String?>(null) }
    var confirmPcOff by remember(vm.id) { mutableStateOf(false) }
    var brightness by remember(vm.id, level?.currentLevel) {
        mutableFloatStateOf((level?.currentLevel?.toFloat() ?: 0f).coerceIn(0f, 254f))
    }
    fun toggle(next: Boolean) {
        if (onOff == null || busy) return
        busy = true
        error = null
        scope.launch {
            try {
                if (next) onOff.on() else onOff.off()
            } catch (e: Exception) { error = e.message ?: "Command failed" }
            finally { busy = false }
        }
    }
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable(onClick = onOpen)) {
                    Text(name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text(if (busy) "Switching…" else status, color = Pale, fontSize = 12.sp)
                }
                if (onOff != null) {
                    Switch(
                        checked = onOff.onOff == true,
                        onCheckedChange = { value ->
                            if (!value && name.contains("pc", ignoreCase = true)) confirmPcOff = true
                            else toggle(value)
                        },
                        enabled = !busy
                    )
                } else {
                    Text("Details", color = Sky, modifier = Modifier.clickable(onClick = onOpen))
                }
            }
            if (level?.currentLevel != null) {
                Spacer(Modifier.height(5.dp))
                Text("Brightness ${((brightness / 254f) * 100).toInt()}%", color = Pale, fontSize = 13.sp)
                Slider(value = brightness, onValueChange = { brightness = it }, valueRange = 0f..254f,
                    onValueChangeFinished = {
                        scope.launch {
                            try {
                                level.moveToLevelWithOnOff(
                                    level = brightness.toInt().toUByte(), transitionTime = null,
                                    optionsMask = LevelControlTrait.OptionsBitmap(),
                                    optionsOverride = LevelControlTrait.OptionsBitmap()
                                )
                            } catch (e: Exception) { error = e.message ?: "Brightness failed" }
                        }
                    })
            }
            if (error != null) Text(error ?: "", color = Color(0xFFFF9B8D), fontSize = 12.sp)
        }
    }
    if (confirmPcOff) {
        AlertDialog(
            onDismissRequest = { confirmPcOff = false },
            title = { Text("Switch off PC plug?") },
            text = { Text("This cuts electricity immediately. Shut Windows down first.") },
            confirmButton = { TextButton(onClick = { confirmPcOff = false; toggle(false) }) { Text("Switch off") } },
            dismissButton = { TextButton(onClick = { confirmPcOff = false }) { Text("Cancel") } }
        )
    }
}
