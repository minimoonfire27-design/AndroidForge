package uk.co.shawcontrol;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Shaw Control v0.9, minimal sign-in and Google Home companion shortcut. */
public final class MainActivity extends Activity {
    private static final int BG=0xff091321, CARD=0xff14253b, EDGE=0xff263d58;
    private static final int BLUE=0xff65bcff, WHITE=0xffeef6ff, MUTED=0xff91a9c5;
    private static final int GREEN=0xff80e1bb, AMBER=0xffffcd83, RED=0xffff9b9b;
    private final Handler timer=new Handler();
    private final ExecutorService io=Executors.newFixedThreadPool(4);
    private final AtomicBoolean deskBusy=new AtomicBoolean(),pcBusy=new AtomicBoolean(),lightBusy=new AtomicBoolean(),monitorBusy=new AtomicBoolean();
    private SecureSettings store;
    private JSONObject settings=new JSONObject();
    private int settingsRevision=0;
    private TapoClient desk,pc;
    private TuyaCloudClient light;
    private boolean syncing=false;
    private Boolean deskOn=null,pcOn=null,lightOn=null;
    private int brightness=-1;
    private TextView date,topline,deskStatus,pcStatus,lightStatus,pcStats,brightnessCaption,footer;
    private Switch deskSwitch,pcSwitch,lightSwitch;
    private SeekBar brightnessSeek;
    private final Runnable poll=new Runnable() {public void run(){clock();refreshAll();timer.postDelayed(this,12000);}};

    private boolean compact(){return getResources().getConfiguration().screenWidthDp < 640;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private GradientDrawable rounded(int fill,int radius){
        GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));return g;
    }
    private GradientDrawable panelBackground(){GradientDrawable g=rounded(CARD,15);g.setStroke(dp(1),EDGE);return g;}
    private TextView text(String value,int size,int colour,boolean bold){
        TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(colour);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;
    }
    private void spacer(LinearLayout p,int h){p.addView(new View(this),lp(1,h));}
    private LinearLayout column(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private Button button(String label){
        Button b=new Button(this);b.setText(label);b.setTextSize(11);b.setAllCaps(false);
        b.setTextColor(WHITE);b.setBackground(rounded(0xff224866,11));b.setPadding(dp(11),dp(3),dp(11),dp(3));return b;
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        store=new SecureSettings(this);
        try { settings=store.load(); } catch(Exception ex) { settings=new JSONObject();
            Toast.makeText(this,"Saved settings could not be unlocked. Re-enter them in Settings.",Toast.LENGTH_LONG).show(); }
        recreateClients();draw();timer.post(poll);
        if(settings.optString("tapo_email","").isEmpty())
            timer.postDelayed(()->showSettings(),550);
    }
    @Override protected void onDestroy(){timer.removeCallbacks(poll);io.shutdownNow();super.onDestroy();}
    private boolean hasTapo(){return desk!=null && pc!=null;}
    private void recreateClients(){
        settingsRevision++;
        deskOn=null;pcOn=null;lightOn=null;brightness=-1;
        String email=settings.optString("tapo_email", ""),pass=settings.optString("tapo_pass", "");
        if(!email.isEmpty()&&!pass.isEmpty()){
            desk=new TapoClient(settings.optString("desk_ip","192.168.1.231"),email,pass);
            pc=new TapoClient(settings.optString("pc_ip","192.168.1.215"),email,pass);
        } else { desk=null;pc=null; }
        String id=settings.optString("tuya_id",""),secret=settings.optString("tuya_secret",""),device=settings.optString("tuya_device","");
        if(!id.isEmpty()&&!secret.isEmpty()&&!device.isEmpty()) {
            try {light=new TuyaCloudClient(settings.optString("tuya_region","https://openapi.tuyaeu.com"),id,secret,device);}
            catch(Exception e){light=null;}
        } else light=null;
    }
    private LinearLayout card(LinearLayout parent,String kicker,String heading,String detail,float weight){
        LinearLayout c=column();c.setPadding(dp(15),dp(13),dp(15),dp(13));c.setBackground(panelBackground());
        LinearLayout.LayoutParams cp=compact()?lp(-1,-2):new LinearLayout.LayoutParams(0,-2,weight);
        if(compact())cp.bottomMargin=dp(12);else cp.rightMargin=dp(9);parent.addView(c,cp);
        TextView badge=text(kicker,10,BLUE,true);c.addView(badge);
        spacer(c,5);c.addView(text(heading,18,WHITE,true));spacer(c,2);
        TextView sub=text(detail,11,MUTED,false);c.addView(sub);spacer(c,10);
        return c;
    }
    private LinearLayout line(LinearLayout p){
        LinearLayout r=row();p.addView(r,lp(-1,-2));return r;
    }
    private void draw(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);scroll.setVerticalScrollBarEnabled(false);
        setContentView(scroll);
        // Crucial v0.4 fix: all children in ScrollView use WRAP_CONTENT height, not a zero-height weight.
        LinearLayout main=column();main.setPadding(dp(18),dp(15),dp(9),dp(15));
        scroll.addView(main,new ScrollView.LayoutParams(-1,-2));
        LinearLayout header=row();main.addView(header,lp(-1,-2));
        LinearLayout name=column();header.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        name.addView(text("Shaw Control",compact()?24:25,WHITE,true));
        name.addView(text("Home",12,MUTED,false));
        date=text("",compact()?11:13,MUTED,false);
        if(compact())name.addView(date);else{LinearLayout.LayoutParams time=lp(-2,-2);time.rightMargin=dp(12);header.addView(date,time);}
        Button refresh=button("↻");header.addView(refresh,lp(compact()?39:75,40));refresh.setOnClickListener(v->refreshAll());
        Button connect=button(compact()?"⚙":"Settings");LinearLayout.LayoutParams settingsLp=lp(compact()?42:-2,40);settingsLp.leftMargin=dp(6);
        header.addView(connect,settingsLp);connect.setOnClickListener(v->showQuickMenu());
        spacer(main,11);
        LinearLayout info=row();main.addView(info,lp(-1,-2));
        topline=text("Your devices",13,BLUE,true);
        info.addView(topline);
        spacer(main,13);
        LinearLayout cards=compact()?column():row();cards.setGravity(Gravity.TOP);main.addView(cards,lp(-1,-2));
        LinearLayout d=card(cards,"TAPO","Desk plug","Monitors and desk",1);
        deskStatus=text("Checking...",12,AMBER,true);d.addView(deskStatus);spacer(d,8);
        LinearLayout dr=line(d);TextView dt=text("POWER",11,MUTED,true);dr.addView(dt,new LinearLayout.LayoutParams(0,-2,1));
        deskSwitch=new Switch(this);deskSwitch.setChecked(false);deskSwitch.setEnabled(false);dr.addView(deskSwitch);
        deskSwitch.setOnCheckedChangeListener((b,on)->{if(!syncing)togglePlug("desk",on);});
        LinearLayout p=card(cards,"TAPO","PC plug","Computer power",1);
        pcStatus=text("Checking...",12,AMBER,true);p.addView(pcStatus);spacer(p,8);
        LinearLayout pr=line(p);pr.addView(text("POWER",11,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));
        pcSwitch=new Switch(this);pcSwitch.setEnabled(false);pr.addView(pcSwitch);
        pcSwitch.setOnCheckedChangeListener((b,on)->{
            if(syncing)return;
            syncing=true;pcSwitch.setChecked(Boolean.TRUE.equals(pcOn));syncing=false;
            if(!on&&Boolean.TRUE.equals(pcOn)) {
                new AlertDialog.Builder(this).setTitle("DANGER: CUT PC MAINS POWER?")
                    .setMessage("Only do this after Windows has fully shut down. Turning this OFF while Windows runs can cause data loss.")
                    .setNegativeButton("CANCEL",(a,x)->{})
                    .setPositiveButton("YES, PC IS SHUT DOWN",(a,x)->togglePlug("pc",false)).show();
            }else togglePlug("pc",on);
        });
        LinearLayout l=card(cards,"LIGHT","Jamie's light","Google Home or advanced Tuya setup",1.12f);
        lightStatus=text("Setup needed",12,AMBER,true);l.addView(lightStatus);spacer(l,7);
        LinearLayout lr=line(l);lr.addView(text("POWER",11,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));
        lightSwitch=new Switch(this);lightSwitch.setEnabled(false);lr.addView(lightSwitch);
        lightSwitch.setOnCheckedChangeListener((b,on)->{if(!syncing)toggleLight(on);});
        spacer(l,7);LinearLayout br=line(l);br.addView(text("BRIGHTNESS",10,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));
        brightnessCaption=text("—",11,WHITE,true);br.addView(brightnessCaption);
        brightnessSeek=new SeekBar(this);brightnessSeek.setMax(100);brightnessSeek.setProgress(50);brightnessSeek.setEnabled(false);
        l.addView(brightnessSeek,lp(-1,27));
        brightnessSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar bar,int value,boolean user){if(user)brightnessCaption.setText(value+"%");}
            public void onStartTrackingTouch(SeekBar bar){}
            public void onStopTrackingTouch(SeekBar bar){changeBrightness(Math.max(1,bar.getProgress()));}
        });
        Button googleHome=button("Open Google Home  ↗");
        googleHome.setTextSize(13);
        googleHome.setBackground(rounded(0xff1b354e,10));
        l.addView(googleHome,lp(-1,45));
        googleHome.setOnClickListener(v->openGoogleHome());
        spacer(main,12);
        LinearLayout monitor=column();monitor.setPadding(dp(17),dp(12),dp(17),dp(13));monitor.setBackground(panelBackground());main.addView(monitor,lp(-1,-2));
        LinearLayout mt=row();monitor.addView(mt,lp(-1,-2));
        mt.addView(text("PC performance",15,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        if(!compact())mt.addView(text("READ ONLY  ·  PC CAN BE OFF",10,BLUE,true));
        spacer(monitor,7);
        pcStats=text("Not connected. Open Settings → PC Monitor for optional live CPU, GPU and RAM stats.",12,MUTED,false);
        monitor.addView(pcStats);spacer(main,10);
        footer=text("Connections can be changed in Settings.",11,MUTED,false);
        main.addView(footer);clock();displayAll();
    }
    private void clock(){if(date!=null)date.setText(new SimpleDateFormat("HH:mm  ·  EEE d MMM",Locale.UK).format(new Date()));}
    private void status(TextView label,Switch power,Boolean on,boolean running,String unavailable){
        if(label==null||power==null)return;
        if(running){label.setText("●  SWITCHING…");label.setTextColor(AMBER);}
        else if(on==null){label.setText("●  "+unavailable);label.setTextColor(AMBER);}
        else{label.setText(on?"●  ONLINE  ·  ON":"●  ONLINE  ·  OFF");label.setTextColor(on?GREEN:MUTED);}
        syncing=true;
        if(on!=null)power.setChecked(on);
        power.setEnabled(on!=null&&!running);
        syncing=false;
    }
    private String deskMessage="LOGIN NEEDED",pcMessage="LOGIN NEEDED",lightMessage="SETUP NEEDED";
    private void displayAll(){
        status(deskStatus,deskSwitch,deskOn,deskBusy.get(),deskMessage);
        status(pcStatus,pcSwitch,pcOn,pcBusy.get(),pcMessage);
        status(lightStatus,lightSwitch,lightOn,lightBusy.get(),lightMessage);
        if(brightnessCaption!=null){
            if(brightness<0)brightnessCaption.setText("—");else brightnessCaption.setText(brightness+"%");
            brightnessSeek.setEnabled(brightness>=0&&lightOn!=null&&!lightBusy.get());
            if(brightness>=0)brightnessSeek.setProgress(brightness);
        }
    }
    private String shortError(Exception ex){
        if(ex instanceof SecurityException)return "LOGIN REJECTED";
        if(ex instanceof java.net.SocketTimeoutException)return "TIMED OUT";
        if(ex instanceof java.net.ConnectException || ex instanceof java.net.UnknownHostException)return "NOT REACHABLE";
        String m=ex.getMessage()==null?"CONNECTION ERROR":ex.getMessage();
        if(m.toLowerCase(Locale.US).contains("token")||m.toLowerCase(Locale.US).contains("authoriz"))return "AUTHORISATION ERROR";
        return m.length()>34?m.substring(0,34)+"…":m.toUpperCase(Locale.US);
    }
    private void refreshAll(){refreshPlug("desk");refreshPlug("pc");refreshLight();refreshMonitor();}
    private void refreshPlug(String which){
        TapoClient client=which.equals("desk")?desk:pc;AtomicBoolean work=which.equals("desk")?deskBusy:pcBusy;
        if(client==null){if(which.equals("desk")){deskOn=null;deskMessage="LOGIN NEEDED";}else{pcOn=null;pcMessage="LOGIN NEEDED";}displayAll();return;}
        if(!work.compareAndSet(false,true))return;
        final int rev=settingsRevision;
        io.execute(()->{
            Boolean state=null;String problem="";
            try {state=client.isOn();} catch(Exception ex) {problem=shortError(ex);}
            final Boolean result=state;final String err=problem;
            runOnUiThread(()->{
                work.set(false);if(rev!=settingsRevision)return;
                if(which.equals("desk")){deskOn=result;deskMessage=err;}else{pcOn=result;pcMessage=err;}
                displayAll();
            });
        });
    }
    private void togglePlug(String which,boolean on){
        TapoClient client=which.equals("desk")?desk:pc;AtomicBoolean work=which.equals("desk")?deskBusy:pcBusy;
        if(client==null)return;
        if(!work.compareAndSet(false,true)){
            syncing=true;
            if(which.equals("desk"))deskSwitch.setChecked(Boolean.TRUE.equals(deskOn));
            else pcSwitch.setChecked(Boolean.TRUE.equals(pcOn));
            syncing=false;
            Toast.makeText(this,"Checking the plug. Try again in a moment.",Toast.LENGTH_LONG).show();
            return;
        }
        int rev=settingsRevision;
        // Android Switch changes visually on tap; restore last CONFIRMED value until the reply arrives.
        syncing=true;
        if(which.equals("desk"))deskSwitch.setChecked(Boolean.TRUE.equals(deskOn));
        else pcSwitch.setChecked(Boolean.TRUE.equals(pcOn));
        syncing=false;
        if(which.equals("desk"))deskOn=null;else pcOn=null;
        if(which.equals("desk"))deskMessage="SENDING COMMAND";else pcMessage="SENDING COMMAND";
        displayAll();
        io.execute(()->{
            Boolean confirmed=null;String err="";
            try{confirmed=client.setOn(on);}
            catch(Exception ex){err="STATE UNKNOWN • REFRESH";}
            final Boolean state=confirmed;final String problem=err;
            runOnUiThread(()->{
                work.set(false);if(rev!=settingsRevision)return;
                if(which.equals("desk")){deskOn=state;deskMessage=problem;}else{pcOn=state;pcMessage=problem;}
                if(state!=null&&state!=on){
                    if(which.equals("desk")){deskOn=null;deskMessage="WAITING FOR DEVICE";}
                    else{pcOn=null;pcMessage="WAITING FOR DEVICE";}
                    timer.postDelayed(()->refreshPlug(which),3000);
                }
                displayAll();
                if(state==null)Toast.makeText(this,"Command may have worked. Check the physical device; refresh before trying again.",Toast.LENGTH_LONG).show();
                else if(state!=on)Toast.makeText(this,"State not yet updated. Checking again in 3 seconds.",Toast.LENGTH_LONG).show();
            });
        });
    }
    private void refreshLight(){
        final TuyaCloudClient client=light;
        if(client==null){lightOn=null;brightness=-1;lightMessage="TUYA SETUP NEEDED";displayAll();return;}
        if(!lightBusy.compareAndSet(false,true))return;
        final int rev=settingsRevision;
        io.execute(()->{
            TuyaCloudClient.LightState result=null;String message="";
            try{result=client.status();}catch(Exception ex){message=shortError(ex);}
            final TuyaCloudClient.LightState state=result;final String err=message;
            runOnUiThread(()->{
                lightBusy.set(false);if(rev!=settingsRevision)return;
                if(state!=null){lightOn=state.on;brightness=state.brightness;lightMessage="";}
                else{lightOn=null;brightness=-1;lightMessage=err;}
                displayAll();
            });
        });
    }
    private void toggleLight(boolean on){
        final TuyaCloudClient client=light;
        if(client==null)return;
        if(!lightBusy.compareAndSet(false,true)){
            syncing=true;lightSwitch.setChecked(Boolean.TRUE.equals(lightOn));syncing=false;
            Toast.makeText(this,"Light is already updating. Try again in a moment.",Toast.LENGTH_LONG).show();
            return;
        }
        int rev=settingsRevision;
        syncing=true;lightSwitch.setChecked(Boolean.TRUE.equals(lightOn));syncing=false;
        lightOn=null;lightMessage="SENDING COMMAND";displayAll();
        io.execute(()->{
            TuyaCloudClient.LightState state=null;
            try{client.setPower(on);state=client.status();}catch(Exception ignored){}
            final TuyaCloudClient.LightState result=state;
            runOnUiThread(()->{
                lightBusy.set(false);if(rev!=settingsRevision)return;
                if(result==null){lightOn=null;lightMessage="STATE UNKNOWN • REFRESH";}
                else{lightOn=result.on;brightness=result.brightness;lightMessage="";}
                if(result!=null&&result.on!=on){lightOn=null;lightMessage="WAITING FOR LIGHT";timer.postDelayed(()->refreshLight(),3000);}
                displayAll();
                if(result==null)Toast.makeText(this,"Light state unconfirmed; refresh before trying again.",Toast.LENGTH_LONG).show();
            });
        });
    }
    private void changeBrightness(int percent){
        final TuyaCloudClient client=light;
        if(client==null||brightness<0||!lightBusy.compareAndSet(false,true))return;
        int rev=settingsRevision;lightMessage="SETTING BRIGHTNESS";displayAll();
        io.execute(()->{
            TuyaCloudClient.LightState state=null;
            try{client.setBrightness(percent);state=client.status();}catch(Exception ignored){}
            final TuyaCloudClient.LightState result=state;
            runOnUiThread(()->{
                lightBusy.set(false);if(rev!=settingsRevision)return;
                if(result==null){lightOn=null;brightness=-1;lightMessage="STATE UNKNOWN • REFRESH";}
                else{lightOn=result.on;brightness=result.brightness;lightMessage="";}
                displayAll();
                if(result==null)Toast.makeText(this,"Brightness change unconfirmed. Refresh to check.",Toast.LENGTH_LONG).show();
            });
        });
    }
    private void refreshMonitor(){
        String address=settings.optString("monitor_url","").trim();
        if(address.isEmpty()){pcStats.setText("Optional: connect the read-only PC Monitor in Settings. Your plugs work when the PC is off.");return;}
        if(!monitorBusy.compareAndSet(false,true))return;
        String token=settings.optString("monitor_token","");int rev=settingsRevision;
        io.execute(()->{
            String stats;
            HttpURLConnection connection=null;
            try {
                URL url=new URL(address.replaceAll("/$", "")+"/stats");
                connection=(HttpURLConnection)url.openConnection();connection.setConnectTimeout(1700);connection.setReadTimeout(3500);
                connection.setRequestProperty("X-Shaw-Token",token);
                if(connection.getResponseCode()!=200)throw new Exception("unauthorised");
                ByteArrayOutputStream buffer=new ByteArrayOutputStream();
                try(InputStream stream=connection.getInputStream()){
                    byte[] bytes=new byte[1024];int n;while((n=stream.read(bytes))!=-1){buffer.write(bytes,0,n);if(buffer.size()>15000)throw new Exception("long reply");}}
                JSONObject j=new JSONObject(new String(buffer.toByteArray(),StandardCharsets.UTF_8));
                stats="CPU  "+j.optString("cpu","—")+"        GPU  "+j.optString("gpu","—")+"        RAM  "+j.optString("ram","—")
                    +"        GPU TEMP  "+j.optString("gpu_temp","—");
            }catch(Exception ex){stats="PC OFFLINE  ·  Plug and light controls are still independent";}
            finally{if(connection!=null)connection.disconnect();}
            final String line=stats;
            runOnUiThread(()->{monitorBusy.set(false);if(rev==settingsRevision)pcStats.setText(line);});
        });
    }
    private TextView settingLabel(LinearLayout parent,String text){TextView l=text(text,12,BLUE,true);parent.addView(l);return l;}
    private EditText field(LinearLayout parent,String label,String value,boolean password){
        TextView caption=text(label,11,MUTED,false);parent.addView(caption);
        EditText input=new EditText(this);input.setSingleLine(true);input.setTextSize(13);input.setTextColor(WHITE);
        input.setHintTextColor(0xff8399b4);input.setPadding(dp(8),dp(6),dp(8),dp(8));input.setText(value);
        input.setInputType(password?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_CLASS_TEXT);
        parent.addView(input,lp(-1,39));spacer(parent,6);return input;
    }
    private boolean ipValid(String ip){
        String[] bits=ip.split("\\.");if(bits.length!=4)return false;
        try{for(String b:bits)if(b.isEmpty()||Integer.parseInt(b)>255||Integer.parseInt(b)<0)return false;}
        catch(NumberFormatException ex){return false;}
        return true;
    }
    private boolean isHomeIp(String ip){
        if(!ipValid(ip))return false;
        String[] p=ip.split("\\.");int a=Integer.parseInt(p[0]),b=Integer.parseInt(p[1]);
        return a==10||(a==192&&b==168)||(a==172&&b>=16&&b<=31);
    }
    private void showTuyaGuide(){
        new AlertDialog.Builder(this).setTitle("Connect Jamie's Smart Life bulb")
            .setMessage("1. Open the Tuya Developer Platform.\n\n2. Create a Smart Home PaaS cloud project.\n\n3. Under Devices > Link App Account, scan the QR using Smart Life on your phone.\n\n4. Copy the project's Client ID and Secret, plus Jamie's Light Device ID.\n\n5. Enter them in Shaw Control's Settings, then Save & Connect.\n\nTuya may require a paid cloud plan or active trial.")
            .setNegativeButton("CLOSE",null)
            .setPositiveButton("OPEN TUYA WEBSITE",(d,w)->startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://developer.tuya.com/"))))
            .show();
    }
    /** Simple first-run flow: just two fields. All technical options remain optional. */
    // Google Home is a companion app shortcut, NOT an embedded API integration.
    // Native Home APIs require Google's SDK and user-authorised OAuth permissions.
    private void openGoogleHome(){
        try {
            Intent launch=getPackageManager().getLaunchIntentForPackage("com.google.android.apps.chromecast.app");
            if(launch!=null){startActivity(launch);return;}
            new AlertDialog.Builder(this).setTitle("Google Home not installed")
                .setMessage("Install Google Home to control Jamie's Light using your existing Google Home setup.")
                .setNegativeButton("CANCEL",(d,w)->{})
                .setPositiveButton("OPEN PLAY STORE",(d,w)->startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.chromecast.app"))))
                .show();
        } catch(Exception ex){Toast.makeText(this,"Couldn't open Google Home",Toast.LENGTH_LONG).show();}
    }

    private void showSettings(){
        // Clean, single-purpose sign-in. No Tuya project IDs or PC addresses here.
        LinearLayout form=column();form.setPadding(dp(22),dp(25),dp(22),dp(20));
        form.setBackground(rounded(0xff0d1929,18));
        TextView logo=text("S  /  SHAW CONTROL",12,BLUE,true);form.addView(logo);
        spacer(form,19);
        form.addView(text(hasTapo()?"Tapo connected":"Welcome home",27,WHITE,true));
        spacer(form,5);
        form.addView(text("Sign in to your Tapo account once. Your plugs reconnect automatically.",13,MUTED,false));
        spacer(form,25);
        form.addView(text("EMAIL",10,MUTED,true));spacer(form,7);
        EditText email=new EditText(this);email.setSingleLine(true);email.setTextSize(15);
        email.setTextColor(WHITE);email.setHintTextColor(MUTED);email.setHint("you@example.com");
        email.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        email.setText(settings.optString("tapo_email",""));email.setBackground(rounded(CARD,11));
        email.setPadding(dp(16),0,dp(16),0);form.addView(email,lp(-1,52));
        spacer(form,16);
        form.addView(text("PASSWORD",10,MUTED,true));spacer(form,7);
        EditText password=new EditText(this);password.setSingleLine(true);password.setTextSize(15);
        password.setTextColor(WHITE);password.setHintTextColor(MUTED);
        password.setHint(settings.optString("tapo_pass","").isEmpty()?"Your Tapo password":"Saved — leave blank to keep");
        password.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        password.setBackground(rounded(CARD,11));password.setPadding(dp(16),0,dp(16),0);
        form.addView(password,lp(-1,52));spacer(form,24);
        Button save=button("Connect Tapo");save.setTextSize(16);
        save.setBackground(rounded(0xff237bc3,11));form.addView(save,lp(-1,54));
        spacer(form,10);
        Button skip=button("Not now");skip.setTextSize(13);skip.setTextColor(MUTED);
        skip.setBackground(rounded(0xff0d1929,11));form.addView(skip,lp(-1,38));
        spacer(form,7);
        TextView note=text("Securely saved on this phone · No PC needed",11,MUTED,false);
        note.setGravity(Gravity.CENTER);form.addView(note);
        final AlertDialog dialog=new AlertDialog.Builder(this).setView(form).create();
        dialog.setOnShowListener(d->{if(dialog.getWindow()!=null){
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(24),dp(410)),-2);
        }});
        skip.setOnClickListener(v->dialog.dismiss());
        save.setOnClickListener(v->{
            String mail=email.getText().toString().trim(),pw=password.getText().toString();
            if(mail.isEmpty()||!mail.contains("@")){email.setError("Enter your Tapo email");return;}
            if(pw.isEmpty())pw=settings.optString("tapo_pass","");
            if(pw.isEmpty()){password.setError("Enter your password");return;}
            try {
                JSONObject next=new JSONObject(settings.toString());
                next.put("tapo_email",mail).put("tapo_pass",pw);
                if(!next.has("desk_ip"))next.put("desk_ip","192.168.1.231");
                if(!next.has("pc_ip"))next.put("pc_ip","192.168.1.215");
                store.save(next);settings=next;recreateClients();dialog.dismiss();
                displayAll();refreshAll();
                Toast.makeText(this,"Saved. Connecting to Tapo…",Toast.LENGTH_SHORT).show();
            }catch(Exception ex){Toast.makeText(this,"Couldn't save login",Toast.LENGTH_LONG).show();}
        });
        dialog.show();
    }

    private void showQuickMenu(){
        String[] choices={"Tapo login", "Open Google Home", "Advanced connections"};
        new AlertDialog.Builder(this).setTitle("Settings").setItems(choices,(dialog,which)->{
            if(which==0)showSettings();
            else if(which==1)openGoogleHome();
            else showAdvancedSettings();
        }).setNegativeButton("CLOSE",(d,w)->{}).show();
    }

    private void showAdvancedSettings(){
        ScrollView s=new ScrollView(this);LinearLayout body=column();body.setPadding(dp(18),dp(11),dp(18),dp(9));s.addView(body);
        body.addView(text("ADVANCED CONNECTIONS",20,WHITE,true));
        body.addView(text("Set up once. We save your details securely on this Samsung.",12,MUTED,false));spacer(body,11);
        settingLabel(body,"01  /  CONNECT YOUR TAPO PLUGS");
        EditText email=field(body,"Tapo email",settings.optString("tapo_email",""),false);
        EditText pass=field(body,"Tapo password (leave blank to keep saved)","",true);
        body.addView(text("Your Desk and PC plugs use your saved Tapo account. Keep the default addresses unless they change.",11,MUTED,false));
        Button tapoAdvanced=button("Show plug addresses (advanced)  ▾");body.addView(tapoAdvanced,lp(-1,38));
        LinearLayout tapoExtra=column();body.addView(tapoExtra,lp(-1,-2));tapoExtra.setVisibility(View.GONE);
        EditText deskIp=field(tapoExtra,"Desk P100 address",settings.optString("desk_ip","192.168.1.231"),false);
        EditText pcIp=field(tapoExtra,"PC P100 address",settings.optString("pc_ip","192.168.1.215"),false);
        tapoAdvanced.setOnClickListener(v->{boolean open=tapoExtra.getVisibility()!=View.VISIBLE;tapoExtra.setVisibility(open?View.VISIBLE:View.GONE);tapoAdvanced.setText(open?"Hide plug addresses  ▴":"Show plug addresses (advanced)  ▾");});
        spacer(body,13);
        settingLabel(body,"02  /  JAMIE'S LIGHT");
        body.addView(text("Easiest: use Open Google Home on the dashboard to control the light in the Google Home app. Native control inside Shaw Control still needs Tuya credentials or a separate Google Home APIs integration.",11,MUTED,false));
        Button guide=button("How to connect Smart Life  ↗");body.addView(guide,lp(-1,39));guide.setOnClickListener(v->showTuyaGuide());spacer(body,6);
        Button tuyaAdvanced=button("Enter Tuya connection details  ▾");body.addView(tuyaAdvanced,lp(-1,38));
        LinearLayout tuyaExtra=column();body.addView(tuyaExtra,lp(-1,-2));tuyaExtra.setVisibility(View.GONE);
        EditText region=field(tuyaExtra,"Tuya cloud region",settings.optString("tuya_region","https://openapi.tuyaeu.com"),false);
        EditText tuyaId=field(tuyaExtra,"Tuya Cloud Client ID",settings.optString("tuya_id",""),false);
        EditText tuyaSecret=field(tuyaExtra,"Client Secret (blank keeps saved)","",true);
        EditText tuyaDevice=field(tuyaExtra,"Jamie's Light Device ID",settings.optString("tuya_device",""),false);
        tuyaAdvanced.setOnClickListener(v->{boolean open=tuyaExtra.getVisibility()!=View.VISIBLE;tuyaExtra.setVisibility(open?View.VISIBLE:View.GONE);tuyaAdvanced.setText(open?"Hide Tuya details  ▴":"Enter Tuya connection details  ▾");});
        spacer(body,13);
        settingLabel(body,"03  /  PC STATS (OPTIONAL)");
        body.addView(text("CPU, GPU and RAM when your PC is on. Your smart devices work independently.",11,MUTED,false));
        Button pcAdvanced=button("Set up PC monitor  ▾");body.addView(pcAdvanced,lp(-1,38));
        LinearLayout pcExtra=column();body.addView(pcExtra,lp(-1,-2));pcExtra.setVisibility(View.GONE);
        EditText monitorUrl=field(pcExtra,"PC monitor URL (blank disables)",settings.optString("monitor_url",""),false);
        EditText monitorToken=field(pcExtra,"Monitor token (blank keeps saved)","",true);
        pcAdvanced.setOnClickListener(v->{boolean open=pcExtra.getVisibility()!=View.VISIBLE;pcExtra.setVisibility(open?View.VISIBLE:View.GONE);pcAdvanced.setText(open?"Hide PC monitor settings  ▴":"Set up PC monitor  ▾");});
        spacer(body,3);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("SHAW CONTROL  /  EASY SETUP")
            .setView(s).setNegativeButton("CANCEL",(d,w)->{})
            .setPositiveButton("SAVE & CONNECT",null).create();
        dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn->{
            String di=deskIp.getText().toString().trim(),pi=pcIp.getText().toString().trim();
            String r=region.getText().toString().trim(),mu=monitorUrl.getText().toString().trim();
            if(!ipValid(di)||!ipValid(pi)){Toast.makeText(this,"Please enter valid IPs for both Tapo plugs",Toast.LENGTH_LONG).show();return;}
            if(!r.equals("https://openapi.tuyaeu.com")&&!r.equals("https://openapi-weaz.tuyaeu.com")
              &&!r.equals("https://openapi.tuyaus.com")&&!r.equals("https://openapi-ueaz.tuyaus.com")
              &&!r.equals("https://openapi.tuyacn.com")&&!r.equals("https://openapi.tuyain.com")){
                Toast.makeText(this,"Choose a supported Tuya cloud region URL",Toast.LENGTH_LONG).show();return;
            }
            if(!mu.isEmpty()){
                try {URL u=new URL(mu);if(!u.getProtocol().equals("http")||!isHomeIp(u.getHost()))throw new Exception();}
                catch(Exception ex){Toast.makeText(this,"PC monitor needs http://YOUR-PC-IP:8766",Toast.LENGTH_LONG).show();return;}
            }
            try {
                JSONObject config=new JSONObject();
                config.put("desk_ip",di).put("pc_ip",pi);
                config.put("tapo_email",email.getText().toString().trim());
                String pw=pass.getText().toString();config.put("tapo_pass",pw.isEmpty()?settings.optString("tapo_pass",""):pw);
                config.put("tuya_region",r).put("tuya_id",tuyaId.getText().toString().trim())
                    .put("tuya_device",tuyaDevice.getText().toString().trim());
                String ts=tuyaSecret.getText().toString();config.put("tuya_secret",ts.isEmpty()?settings.optString("tuya_secret",""):ts);
                config.put("monitor_url",mu);
                String mt=monitorToken.getText().toString();config.put("monitor_token",mt.isEmpty()?settings.optString("monitor_token",""):mt);
                store.save(config);settings=config;recreateClients();dialog.dismiss();
                displayAll();refreshAll();
                timer.postDelayed(()->refreshAll(),1900);
                Toast.makeText(this,"Saved! Testing connections directly from the tablet…",Toast.LENGTH_LONG).show();
            }catch(Exception ex){Toast.makeText(this,"Could not securely save setup: "+ex.getMessage(),Toast.LENGTH_LONG).show();}
        }));
        dialog.show();
    }
}
