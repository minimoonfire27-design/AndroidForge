"""Shaw Control read-only Windows performance server (optional).

    py -m pip install psutil
    py pc_monitor.py

The smart plugs and light never use this server. Only CPU/GPU/RAM readings do.
The token is generated once and kept in the user's local app-data directory.
Only permit Python through the PRIVATE Windows firewall profile.
"""
import json
import os
import secrets
import subprocess
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

try:
    import psutil
except ImportError:
    raise SystemExit("Install the monitoring library with: py -m pip install psutil")

PORT = 8766
storage = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "ShawControl"
storage.mkdir(parents=True, exist_ok=True)
token_file = storage / "monitor-token.txt"
if token_file.is_file():
    TOKEN = token_file.read_text(encoding="utf-8").strip()
else:
    TOKEN = secrets.token_urlsafe(32)
    token_file.write_text(TOKEN, encoding="utf-8")


def gpu():
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=utilization.gpu,temperature.gpu,memory.used,memory.total",
             "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=2,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), check=True
        ).stdout.strip().splitlines()[0].split(",")
        utilization, temperature, used, total = [part.strip() for part in result]
        return f"{utilization}%", f"{temperature}°C", f"{used}/{total} MiB"
    except (OSError, subprocess.SubprocessError, IndexError, ValueError):
        return "—", "—", "—"


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if not secrets.compare_digest(self.headers.get("X-Shaw-Token", ""), TOKEN):
            return self.reply(403, {"error": "Forbidden"})
        if self.path != "/stats":
            return self.reply(404, {"error": "Not found"})
        cpu = psutil.cpu_percent(interval=0.15)
        mem = psutil.virtual_memory()
        load, temp, vram = gpu()
        return self.reply(200, {
            "cpu": f"{cpu:.0f}%", "gpu": load,
            "ram": f"{mem.percent:.0f}% ({mem.used / 1024**3:.1f}/{mem.total / 1024**3:.1f} GB)",
            "gpu_temp": temp, "gpu_vram": vram,
        })

    def reply(self, code, data):
        body = json.dumps(data).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_args):
        pass


print("\nSHAW CONTROL v0.5 — READ-ONLY PC MONITOR")
print("Only shares CPU, GPU and RAM. Does NOT control plugs or lights.")
print(f"Port: {PORT}   Token file: {token_file}")
print("Token (enter ON TABLET, do not send it to anyone):", TOKEN)
print("Keep this running while you want PC monitoring.")
print("Allow access on PRIVATE networks only in Windows Firewall.\n")
try:
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
except KeyboardInterrupt:
    print("Monitor stopped")
