# Shaw Control v0.7 — Samsung Galaxy A13 control dashboard

A native Android 9+ landscape dashboard adapted for the Samsung Galaxy A13 (SM-A135F). This is SOURCE, not a compiled APK. See SAMSUNG-READ-ME-FIRST.txt for direct local Android Studio build instructions.

## What works in the app source

- **Tapo Desk & PC plugs:** KLAP v1/v2 direct LAN communication from Android; no Python bridge or running PC. Independent individual status checks and command queues. A switch is only enabled when its device has confirmed its state. Connection timeout never causes automatic duplicate ON/OFF commands. Save login/IPs once with Android Keystore-backed encrypted storage.
- **Jamie's Light:** Tuya *official cloud IoT API* integration for on/off and brightness. Requires you to link Smart Life to your own authorised Tuya IoT cloud project. No PC middleman. The app checks which brightness data point the bulb actually supports.
- **PC CPU/GPU/RAM:** optional, read-only `scripts/pc_monitor.py` server on Windows (port 8766), only needed if you want live PC telemetry while the PC is running. Never handles smart-plug commands.
- **Dashboard:** restored and fixed proper on-screen card heights for the Samsung Galaxy A13 landscape display. Separate setup sections, Refresh and Settings buttons always visible, clock, states and error feedback. PC mains plug requires explicit confirmation before OFF.
- **Security:** Android Keystore AES-GCM local credential storage, cloud uses HTTPS, Tuya endpoints allowlisted; no credentials embedded in the source. Android backup disabled. PC telemetry token is random and saved locally. No old `bridge.py` dependency.

## Reality check: device testing

Source is implemented, but the actual Tapo P100 firmware, Tuya project and Fire hardware were **not accessible in this environment**. You must build and test; there is no claim that your personal devices already work. If the IoT API expires/has no entitlement, cloud commands will report an error. Android auto-launch at boot depends on its restrictions and may not work without additional user configuration.

## Build and install

1. In your private GitHub repo, replace existing project files with the contents of this `ShawControl/` folder (including `.github/workflows/build-apk.yml` and the `.keystore` file).
2. Go to **Actions → Build Shaw Control APK → Run workflow** or commit to `main`.
3. Download **ShawControl-v0.7-apk**, extract `app-debug.apk`.
4. Connect your tablet to Windows (USB debugging), and in CMD:

   ```cmd
   cd /d "C:\Users\minim\Downloads\ADK"
   adb devices
   adb uninstall uk.co.shawcontrol
   adb install "C:\Users\minim\Downloads\ShawControl-v0.7-apk\app-debug.apk"
   adb shell monkey -p uk.co.shawcontrol 1
   ```

   **IMPORTANT:** The APK path depends on where you actually extracted the artifact. You need the one-time uninstall only if the previous APK is signed with a different key. It deletes v0.4 settings. The checked-in local test signing key is for this private project only and permits consistent v0.5+ upgrades when unchanged. Do not distribute it or publish a production app signed with it.

5. On first launch, **Settings → Tapo**: enter Tapo credentials and confirm LAN IPs (default Desk `192.168.1.231`; PC `192.168.1.215`). Save & Connect. **Test Desk first. Do not turn off PC plug when Windows is running.**

## Linking Jamie's Smart Life bulb to Tuya Cloud

**You cannot connect a custom app to Smart Life by typing its email/password alone.** This uses Tuya's documented IoT Cloud API rather than misusing those credentials.

1. In browser, go to [Tuya Developer Platform](https://developer.tuya.com/), sign up or sign in.
2. Create a Cloud Development **Smart Home PaaS** project (not Custom Development). Choose the data centre corresponding to the Smart Life account (for UK commonly **Central Europe**, but check your account).
3. Subscribe to required cloud API services/permissions (**IoT Core** and the relevant Smart Home service), bearing in mind Tuya's trial, quota and pricing conditions.
4. In the project, go to **Devices → Link App Account**, add an account, and scan the QR code using the **Smart Life** mobile app. Confirm the link.
5. Under **All Devices** find Jamie's bulb and copy its **Device ID**. From project Overview/Authorization Key copy **Access ID (Client ID)** and **Access Secret**.
6. On Shaw Control, open **Settings → Smart Life** and enter the project **endpoint**, **Client ID**, **Secret**, **Device ID**. For Central Europe use `https://openapi.tuyaeu.com`. **Never share the Secret.**
7. Save & Connect, then refresh. If the cloud API isn't authorised, the app will show the returned error; link the Smart Life account and check service subscriptions.

Tuya official docs: [Link account and API key](https://developer.tuya.com/en/docs/developer/apply-cloud-api-key?id=Kff30z8sv62ah), [Send commands](https://developer.tuya.com/en/docs/cloud/e2512fb901?id=Kag2yag3tiqn5), [Check status](https://developer.tuya.com/en/docs/cloud/1ef1a3044b?id=Kconf2usgnfwo).

## Optional live PC stats, not a bridge

On Windows (only while you want CPU/GPU/RAM readings):

```cmd
py -m pip install psutil
py pc_monitor.py
```

The script is at `scripts/pc_monitor.py`. It prints an access token once and retains it in `%LOCALAPPDATA%\ShawControl\monitor-token.txt`. Enter **http://192.168.1.180:8766** (change IP if necessary) and the token under Settings → PC Monitor. Keep the script running. Allow Python in Windows Firewall on your **Private network only**. The script only answers authenticated **GET /stats**, no POST or plug controls.

## Troubleshooting

- **Blank/missing cards:** v0.4 had a zero-height weighted row inside a ScrollView; v0.5 uses wrap-content card rows.
- **Tapo login rejected:** email/password case-sensitive; check the TP-Link Tapo app for Third-Party Compatibility, which has security trade-offs. Check home LAN and actual plug IPs.
- **Timed out / state unknown:** a power command may already have happened. **Check physical device and press Refresh** before trying again. No automatic duplicate write is issued.
- **Tuya auth error:** check Client ID, Secret, data centre, device linking, cloud subscriptions and trial status. Device must expose standard `switch_led` and either `bright_value_v2` or `bright_value` for brightness.
- **PC OFFLINE:** expected while PC is off or optional monitor isn't running. Plugs still work directly from tablet.
- **Fire tablet boot:** auto-start is best-effort; Fire OS may block starting an Activity from a background receiver. App can be launched manually.

## Technical notes

- Only Android built-in APIs (`org.json`, AES-GCM Android Keystore, Java `HttpURLConnection`, `javax.crypto`) are used. No third-party Android dependencies.
- Tapo requests are via local unencrypted HTTP carrying encrypted KLAP payloads (not ordinary plaintext commands). Networks must be trusted.
- Tuya cloud signing follows its documented HMAC-SHA256 stringToSign format and exchanges a project credential for an expiring access token. Config remains on the device.
- App is not hardened for production or public release; the bundled fixed debug signing key is for this private test project.
