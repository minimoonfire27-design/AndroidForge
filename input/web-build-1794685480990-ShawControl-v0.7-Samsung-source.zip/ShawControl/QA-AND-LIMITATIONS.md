# Shaw Control v0.5 — verification and limitations

## Verification performed during creation

- Java source compile check against minimal Android and org.json **compile-time stubs** — **PASS** (this is **not** the same as an Android Gradle APK build).
- TP-Link KLAP version 1 mock device: handshake, session-cookie, IV/key derivation, encrypted commands and session reuse — **PASS**.
- TP-Link KLAP version 2 mock device: handshake, session-cookie, IV/key derivation, encrypted commands and session reuse — **PASS**.
- Tuya API HMAC-SHA256 using the exact published Tuya request-signature test vector — **PASS**.
- Python PC telemetry script syntax compile — **PASS**.
- Python PC monitor integration: authenticated GET returns metrics and requests without token receive HTTP 403 — **PASS**.

## Still to verify on hardware

- GitHub Actions/Android Gradle real APK build (no Android SDK or network download available in the creation environment).
- Actual Fire 7 UI, layout and key persistence in Android Keystore.
- Actual Tapo P100 firmware 1.4.6 direct authentication and power/status behavior.
- Actual Tuya linked cloud project permissions/region and Jamie's bulb's supported brightness/status data points.
- Windows auto-launch/read-only monitor and Windows Firewall settings on the user's computer.

## Safety

A power command can still complete after a network timeout. This app deliberately does **not** auto-retry ON/OFF writes, marks results ambiguous after a failed response and prompts the user to verify the physical state. Never switch OFF the **PC plug** until Windows has shut down. Keep the stable development signing key private.
