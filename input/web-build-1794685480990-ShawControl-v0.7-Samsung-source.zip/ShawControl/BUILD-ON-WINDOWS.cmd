@echo off
setlocal
cd /d "%~dp0"
echo SHAW CONTROL 0.6 - LOCAL WINDOWS APK BUILD
echo.
set "GRADLE_EXE="
where gradle >nul 2>nul && set "GRADLE_EXE=gradle"
if exist "%~dp0gradlew.bat" set "GRADLE_EXE=%~dp0gradlew.bat"
if not defined GRADLE_EXE (
 echo No Gradle executable was found.
 echo Please install Android Studio and open this project.
 echo In Android Studio choose Build - Build Bundle(s) / APK(s) - Build APK(s).
 echo Your output will be: app\build\outputs\apk\debug\app-debug.apk
 echo No APK has been built by this script.
 pause
 exit /b 1
)
if not defined ANDROID_HOME if not defined ANDROID_SDK_ROOT set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not exist "%ANDROID_HOME%\platforms\android-35\android.jar" (
 echo Android SDK platform 35 not found at: %ANDROID_HOME%
 echo Open Android Studio SDK Manager and install Android API 35.
 pause
 exit /b 1
)
call "%GRADLE_EXE%" --no-daemon assembleDebug
if errorlevel 1 (
 echo BUILD FAILED - see messages above.
 pause
 exit /b 1
)
echo.
echo APK CREATED: "%~dp0app\build\outputs\apk\debug\app-debug.apk"
pause
