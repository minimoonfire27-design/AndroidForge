@echo off
setlocal
cd /d "%~dp0"
set "APK=%~dp0app\build\outputs\apk\debug\app-debug.apk"
if not exist "%APK%" (
 echo No APK found. Build the Android project first.
 pause
 exit /b 1
)
set "ADB=%USERPROFILE%\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe"
if not exist "%ADB%" (
 echo Can't locate ADB at %ADB%
 pause
 exit /b 1
)
"%ADB%" devices
"%ADB%" install -r "%APK%"
if errorlevel 1 (
 echo Install failed. Do NOT uninstall until you know why.
 pause
 exit /b 1
)
"%ADB%" shell monkey -p uk.co.shawcontrol 1
pause
