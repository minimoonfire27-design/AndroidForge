package uk.co.shawcontrol;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Direct, local network KLAP v1/v2 for Tapo plugs. No Windows service involved.
 *  Commands are NEVER retried automatically: a timed-out ON/OFF could have succeeded.
 */
public final class TapoClient {
    private final String host, username, password;
    private byte[] key, ivPrefix, signature;
    private int sequence;
    private String cookie;
    private long expiresAt;

    public TapoClient(String host, String username, String password) {
        this.host = host.trim(); this.username = username.trim(); this.password = password;
    }
    private static byte[] str(String s) { return s.getBytes(StandardCharsets.UTF_8); }
    private static byte[] hash(String algo, byte[]... inputs) throws Exception {
        MessageDigest md = MessageDigest.getInstance(algo);
        for (byte[] input : inputs) md.update(input);
        return md.digest();
    }
    private static byte[] part(byte[] src, int start, int end) { return Arrays.copyOfRange(src, start, end); }
    private static byte[] seqBytes(int n) { return new byte[]{(byte)(n>>>24),(byte)(n>>>16),(byte)(n>>>8),(byte)n}; }
    private static byte[] join(byte[]... parts) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        for (byte[] b:parts) out.write(b);
        return out.toByteArray();
    }
    private byte[] post(String path, byte[] payload) throws Exception {
        HttpURLConnection connection = (HttpURLConnection)new URL("http://"+host+path).openConnection();
        connection.setConnectTimeout(1700);
        connection.setReadTimeout(3000);
        connection.setRequestMethod("POST");
        connection.setInstanceFollowRedirects(false);
        connection.setUseCaches(false);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/octet-stream");
        connection.setRequestProperty("Connection", "close");
        if (cookie != null) connection.setRequestProperty("Cookie",cookie);
        try {
            try (OutputStream out=connection.getOutputStream()) { out.write(payload); }
            int status=connection.getResponseCode();
            if (path.endsWith("handshake1")) {
                String raw=connection.getHeaderField("Set-Cookie");
                if (raw != null) {
                    for (String item:raw.split(";")) {
                        if (item.trim().startsWith("TP_SESSIONID=")) cookie=item.trim();
                    }
                }
            }
            if (status!=200) throw new IOException("Tapo HTTP " + status + " at " + path.split("\\?")[0]);
            try(InputStream in=connection.getInputStream();ByteArrayOutputStream result=new ByteArrayOutputStream()) {
                byte[] buffer=new byte[2048];int read;
                while ((read=in.read(buffer))!=-1) {
                    result.write(buffer,0,read);
                    if (result.size()>32768) throw new IOException("Unexpectedly long Tapo reply");
                }
                return result.toByteArray();
            }
        } finally { connection.disconnect(); }
    }
    private void handshake() throws Exception {
        key=null; cookie=null;
        byte[] local=new byte[16];new SecureRandom().nextBytes(local);
        byte[] response=post("/app/handshake1",local);
        if(response.length!=48) throw new IOException("This plug did not return a KLAP handshake");
        byte[] remote=part(response,0,16), challenge=part(response,16,48);
        byte[] v1=hash("MD5",hash("MD5",str(username)),hash("MD5",str(password)));
        byte[] v2=hash("SHA-256",hash("SHA-1",str(username)),hash("SHA-1",str(password)));
        byte[] auth; boolean secondVersion;
        if(MessageDigest.isEqual(challenge,hash("SHA-256",local,remote,v2))) { auth=v2;secondVersion=true; }
        else if(MessageDigest.isEqual(challenge,hash("SHA-256",local,v1))) { auth=v1;secondVersion=false; }
        else throw new SecurityException("Tapo login not accepted. Check login and Third-Party Compatibility in Tapo settings");
        byte[] second=secondVersion?hash("SHA-256",remote,local,auth):hash("SHA-256",remote,auth);
        post("/app/handshake2",second);
        key=part(hash("SHA-256",str("lsk"),local,remote,auth),0,16);
        byte[] iv=hash("SHA-256",str("iv"),local,remote,auth);
        ivPrefix=part(iv,0,12);
        byte[] initial=part(iv,28,32); // IV sequence is taken from LAST four bytes of SHA256.
        sequence=((initial[0]&255)<<24)|((initial[1]&255)<<16)|((initial[2]&255)<<8)|(initial[3]&255);
        signature=part(hash("SHA-256",str("ldk"),local,remote,auth),0,28);
        expiresAt=System.currentTimeMillis()+55*60*1000L;
    }
    private JSONObject send(String method, JSONObject parameters) throws Exception {
        if(key==null||System.currentTimeMillis()>expiresAt) handshake();
        JSONObject json=new JSONObject().put("method",method);
        if(parameters!=null)json.put("params",parameters);
        sequence++;
        byte[] counter=seqBytes(sequence), iv=join(ivPrefix,counter);
        Cipher cipher=Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"),new IvParameterSpec(iv));
        byte[] encrypted=cipher.doFinal(str(json.toString()));
        byte[] sign=hash("SHA-256",signature,counter,encrypted);
        byte[] raw;
        try { raw=post("/app/request?seq="+sequence,join(sign,encrypted)); }
        catch(Exception ex) { key=null; throw ex; } // Never automatically resend a potentially applied power command.
        if(raw.length<=32) { key=null;throw new IOException("Invalid encrypted Tapo reply"); }
        cipher.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new IvParameterSpec(iv));
        JSONObject reply=new JSONObject(new String(cipher.doFinal(part(raw,32,raw.length)),StandardCharsets.UTF_8));
        if(reply.optInt("error_code",0)!=0) throw new IOException("Tapo error code "+reply.optInt("error_code"));
        return reply;
    }
    public synchronized boolean isOn() throws Exception {
        JSONObject result=send("get_device_info",null).optJSONObject("result");
        if(result==null||!result.has("device_on")) throw new IOException("No ON/OFF state in plug reply");
        return result.getBoolean("device_on");
    }
    /** Sends ON/OFF exactly once. Returns a confirmed read-back of the state. */
    public synchronized boolean setOn(boolean on) throws Exception {
        send("set_device_info",new JSONObject().put("device_on",on));
        return isOn();
    }
}
