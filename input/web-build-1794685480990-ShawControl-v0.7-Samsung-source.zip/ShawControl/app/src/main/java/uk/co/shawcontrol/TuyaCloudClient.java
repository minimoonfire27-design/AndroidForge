package uk.co.shawcontrol;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.UUID;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/** Tuya IoT Cloud API, using a user-owned authorised IoT project, no PC intermediary.
 * A Smart Life account must first be linked to the cloud project (Tuya requirement).
 */
public final class TuyaCloudClient {
    public static final class LightState {
        public final boolean on;
        public final int brightness; // 0..100, -1 when device doesn't expose brightness
        public final String brightnessCode;
        LightState(boolean on,int brightness,String code){this.on=on;this.brightness=brightness;this.brightnessCode=code;}
    }
    private final String endpoint,clientId,secret,deviceId;
    private String accessToken;
    private long tokenExpiry;
    private String brightnessCode="bright_value_v2";
    public TuyaCloudClient(String region,String id,String clientSecret,String device) {
        if(!region.matches("https://(openapi\\.tuya(eu|us|cn|in)\\.com|openapi-(weaz\\.tuyaeu|ueaz\\.tuyaus)\\.com)"))
            throw new IllegalArgumentException("Choose an approved Tuya region");
        endpoint=region;clientId=id.trim();secret=clientSecret;deviceId=device.trim();
    }
    private static byte[] bytes(String text){return text.getBytes(StandardCharsets.UTF_8);}
    private static String hex(byte[] data){StringBuilder b=new StringBuilder();for(byte x:data)b.append(String.format(Locale.US,"%02x",x&255));return b.toString();}
    private static String sha256(String text) throws Exception {return hex(MessageDigest.getInstance("SHA-256").digest(bytes(text)));}
    private String hmac(String text) throws Exception {
        Mac mac=Mac.getInstance("HmacSHA256");mac.init(new SecretKeySpec(bytes(secret),"HmacSHA256"));
        return hex(mac.doFinal(bytes(text))).toUpperCase(Locale.US);
    }
    private JSONObject http(String method,String path,String body,String token) throws Exception {
        String timestamp=Long.toString(System.currentTimeMillis());
        String nonce=UUID.randomUUID().toString().replace("-","");
        String signed=method+"\n"+sha256(body==null?"":body)+"\n\n"+path;
        String signature=hmac(clientId+(token==null?"":token)+timestamp+nonce+signed);
        HttpURLConnection c=(HttpURLConnection)new URL(endpoint+path).openConnection();
        c.setConnectTimeout(4000); c.setReadTimeout(6500);c.setUseCaches(false);
        c.setRequestMethod(method);
        c.setRequestProperty("client_id",clientId);
        c.setRequestProperty("sign",signature);
        c.setRequestProperty("sign_method","HMAC-SHA256");
        c.setRequestProperty("t",timestamp);
        c.setRequestProperty("nonce",nonce);
        if(token!=null)c.setRequestProperty("access_token",token);
        if(body!=null){
            c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");
        }
        try {
            if(body!=null)try(OutputStream out=c.getOutputStream()){out.write(bytes(body));}
            int status=c.getResponseCode();
            InputStream stream=status>=400?c.getErrorStream():c.getInputStream();
            if(stream==null)throw new IOException("Tuya HTTP "+status);
            ByteArrayOutputStream output=new ByteArrayOutputStream();
            try(InputStream in=stream){byte[] buffer=new byte[2048];int count;
                while((count=in.read(buffer))!=-1){output.write(buffer,0,count);if(output.size()>100000)throw new IOException("Tuya response too large");}}
            JSONObject reply=new JSONObject(new String(output.toByteArray(),StandardCharsets.UTF_8));
            if(status!=200||!reply.optBoolean("success",false))
                throw new IOException("Tuya: "+reply.optString("msg","HTTP "+status)+" ("+reply.optString("code","request failed")+")");
            return reply;
        } finally {c.disconnect();}
    }
    private void token() throws Exception {
        if(accessToken!=null&&System.currentTimeMillis()<tokenExpiry) return;
        JSONObject auth=http("GET","/v1.0/token?grant_type=1",null,null).getJSONObject("result");
        accessToken=auth.getString("access_token");
        long duration=auth.optLong("expire_time",7200);
        tokenExpiry=System.currentTimeMillis()+Math.max(120, duration-120)*1000L;
    }
    private JSONObject query(String method,String path,String body) throws Exception {
        token();
        try { return http(method,path,body,accessToken); }
        catch(IOException error) {
            // A rejected token may be refreshed, but a WRITE is never replayed automatically.
            if("GET".equals(method)&&error.getMessage()!=null&&error.getMessage().contains("token")) {
                accessToken=null;token();return http(method,path,body,accessToken);
            }
            throw error;
        }
    }
    public synchronized LightState status() throws Exception {
        JSONArray entries=query("GET","/v1.0/iot-03/devices/"+deviceId+"/status",null).getJSONArray("result");
        Boolean on=null;int brightness=-1;String code=null;
        for(int i=0;i<entries.length();i++){
            JSONObject entry=entries.getJSONObject(i);String name=entry.optString("code","");
            if(name.equals("switch_led")||name.equals("switch"))on=entry.getBoolean("value");
            if(name.equals("bright_value_v2")){code=name;brightness=Math.round((Math.max(10,entry.getInt("value"))-10)*100f/990f);}
            else if(name.equals("bright_value")&&code==null){code=name;brightness=Math.round((Math.max(25,entry.getInt("value"))-25)*100f/230f);}
        }
        if(on==null)throw new IOException("No switch_led in Tuya device status. Check Device ID");
        if(code!=null)brightnessCode=code;
        return new LightState(on,brightness,code);
    }
    public synchronized void setPower(boolean on) throws Exception {command("switch_led",on);}
    public synchronized void setBrightness(int percent) throws Exception {
        percent=Math.max(1,Math.min(100,percent));
        int value=brightnessCode.equals("bright_value")?25+Math.round(percent*230f/100f):10+Math.round(percent*990f/100f);
        command(brightnessCode,value);
    }
    private void command(String code,Object value) throws Exception {
        JSONObject one=new JSONObject().put("code",code).put("value",value);
        JSONObject payload=new JSONObject().put("commands",new JSONArray().put(one));
        query("POST","/v1.0/iot-03/devices/"+deviceId+"/commands",payload.toString());
    }
}
