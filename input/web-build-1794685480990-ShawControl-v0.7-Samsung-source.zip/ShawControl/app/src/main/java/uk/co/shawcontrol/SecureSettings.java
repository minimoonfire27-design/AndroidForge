package uk.co.shawcontrol;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Encrypt configuration and secrets at rest with Android Keystore AES-GCM. */
public final class SecureSettings {
    private static final String ALIAS="shaw-control-keystore-v05";
    private final Context context;
    public SecureSettings(Context c){context=c;}
    private SecretKey key() throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(!store.containsAlias(ALIAS)) {
            KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            gen.generateKey();
        }
        return (SecretKey)store.getKey(ALIAS,null);
    }
    public JSONObject load() throws Exception {
        SharedPreferences pref=context.getSharedPreferences("secure_config",Context.MODE_PRIVATE);
        String encrypted=pref.getString("data","");
        if(encrypted.isEmpty())return new JSONObject();
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(pref.getString("iv",""),Base64.NO_WRAP)));
        byte[] data=cipher.doFinal(Base64.decode(encrypted,Base64.NO_WRAP));
        return new JSONObject(new String(data,StandardCharsets.UTF_8));
    }
    public void save(JSONObject json) throws Exception {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] cipherText=cipher.doFinal(json.toString().getBytes(StandardCharsets.UTF_8));
        context.getSharedPreferences("secure_config",Context.MODE_PRIVATE).edit()
          .putString("iv",Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP))
          .putString("data",Base64.encodeToString(cipherText,Base64.NO_WRAP)).commit();
    }
}
