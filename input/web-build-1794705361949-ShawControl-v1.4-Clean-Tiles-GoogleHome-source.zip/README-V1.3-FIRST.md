# Shaw Control v1.3 — FAST REVERSE / LIVE STATE

This is Android **source**, not an installed APK. You need to compile it.

## What makes the light switch usable now

The physical light was turning ON while Google's old cloud state still said OFF.
The v1.2 UI waited for Google and disabled the control for up to 12 seconds.

v1.3 keeps **your most recent request** visible and accepts a reverse tap instantly.
It sends explicit `on()` / `off()` commands, and if the prior command is still in flight,
queues your latest manual request until that first command returns (up to 8 seconds).
No automatic repeats. A separate label shows whether Google's state has confirmed.

## Build and install

Use a private Android build setup (Android Studio / private CI) with the included
Home API SDK Maven artifacts. This project needs the Google Home SDK and modern
Gradle / Kotlin / Java 17 dependencies.

* Package: `uk.co.shawcontrol.home`
* Version: `1.3.0-fast-reverse` (versionCode 4)
* APK signing: use a single persistent **private** signing key if possible.
  AndroidForge has previously rotated signing certificates between builds.
  Your OAuth Android client in Google Cloud MUST match the SHA-1 of the exact
  signed APK. If your signing key changes again, register that new fingerprint.
* Never put a keystore, Google OAuth secret, or the SDK proprietary files in a
  public GitHub repository. This ZIP contains the supplied SDK, so keep it private.

## Quick test

Test only a light, not the PC power plug.

1. Sign into Google Home if prompted. Press ON and watch the physical light.
2. If the switch is still waiting for confirmation, press OFF immediately.
3. The display should change to OFF at once. If ON is still in flight,
   it will show `Queued OFF` and send OFF after the ON command returns.
4. Compare the `Home API response: … ms` line and the physical light response.
5. `Refresh Google's state` reads only; it never toggles power again.

**Caution:** requested state is explicitly *unconfirmed* until a new cloud report.
The cloud may still be slow, and the physical device may not obey a command.

## Diagnostic command (after every APK)

Clear old logs before testing:

    "C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -c

After reproducing an error, immediately save:

    "C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -d -v time > "%USERPROFILE%\Desktop\shaw-error.txt"

For missing lines use a *live* capture instead (run before reproducing,
press Ctrl+C in CMD after):

    "C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -v time > "%USERPROFILE%\Desktop\shaw-live-error.txt"

Look for `ShawControl.Commands` in the log. Don't post whole logs publicly;
they can contain private account / device details.

## Test status

Pure Kotlin reconciliation tests pass (8 checks). Android compile and
Google Home integration are **not** run in this environment.
