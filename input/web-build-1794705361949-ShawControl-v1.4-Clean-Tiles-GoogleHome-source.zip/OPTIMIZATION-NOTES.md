# Shaw Control v1.1 — latency and reliability improvements

Based on the working v1.0 real-Google-Home build, retaining identical package name `uk.co.shawcontrol.home`, SDK, permissions, and account setup.

## Improvements
- Immediate **Sending command…** feedback and non-blocking spinner
- Prevents duplicate power commands while the first command is in flight or awaiting a confirmed state
- Treats Google Home device-state updates as authoritative; does not falsely mark a command successful
- If no state confirmation appears after 8 seconds, shows a clear warning (no silent retries or resends)
- Shows real command exceptions on the device card
- Brightness changes send one Home API command only when the slider is released, with disable-while-sending
- Slider follows incoming Home API brightness state when not being edited/sent
- PC plug requires explicit power-off confirmation and never automatically retries an uncertain command
- Version bumped to 1.1.0 with versionCode 2

## Limitations
- Network and Google Home device response latency cannot be eliminated by an app UI update.
- This project has NOT been compiled in this environment (Android SDK / Gradle dependencies unavailable).
- Keep Google Home SDK binaries private; do not publish this ZIP to a public repository.
- Google OAuth credentials and signing SHA-1 must still match the actual APK.
- If an earlier AndroidForge build uses a different signing key, updating in place will fail; do not uninstall before confirming your data/permissions can be restored.
