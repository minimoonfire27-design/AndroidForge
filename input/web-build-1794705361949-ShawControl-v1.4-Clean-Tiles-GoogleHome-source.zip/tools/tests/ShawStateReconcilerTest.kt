import com.example.googlehomeapisampleapp.view.ShawStateReconciler

/** Run with kotlinc + kotlin; no Android dependencies required. */
fun main() {
    // Cached OFF must NOT confirm an OFF sent after an unverified ON.
    check(!ShawStateReconciler.isConfirmed(false, 11, false, 11L))
    // Live ON update confirms the ON command.
    check(ShawStateReconciler.isConfirmed(true, 11, true, 12L))
    // A stale OFF update must not confirm an ON request.
    check(!ShawStateReconciler.isConfirmed(true, 11, false, 12L))
    // The user can request OFF without waiting for the previous ON to appear
    // in Google's reported state (the UI's requested state is separate).
    val lastRequested = true
    val userRequestsOff = !lastRequested
    check(!userRequestsOff)
    // After reverse: even a cached OFF should not be called freshly confirmed.
    check(!ShawStateReconciler.isConfirmed(false, 12L, false, 12L))
    check(ShawStateReconciler.isConfirmed(false, 12L, false, 13L))
    // Brightness tolerance never turns an old value into confirmation.
    check(!ShawStateReconciler.isConfirmedWithinOne(150, 9L, 150, 9L))
    check(ShawStateReconciler.isConfirmedWithinOne(150, 9L, 149, 10L))
    check(!ShawStateReconciler.isConfirmedWithinOne(150, 9L, 140, 10L))
    println("PASS: 8 state-sync reconciliation checks")
}
