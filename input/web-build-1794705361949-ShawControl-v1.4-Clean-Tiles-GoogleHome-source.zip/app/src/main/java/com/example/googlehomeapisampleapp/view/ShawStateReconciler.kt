package com.example.googlehomeapisampleapp.view

/**
 * Pure, testable state reconciliation for slow Google Home cloud devices.
 *
 * A target is confirmed only when the provider's reported state moves to that
 * target after the request began. The cached value that was already present
 * when a command was sent must not be mistaken for fresh confirmation.
 */
object ShawStateReconciler {
    fun <T : Any> isConfirmed(
        requested: T?,
        revisionWhenRequested: Long,
        reported: T?,
        currentRevision: Long
    ): Boolean = requested != null &&
        currentRevision > revisionWhenRequested && reported == requested

    fun isConfirmedWithinOne(
        requested: Int?,
        revisionWhenRequested: Long,
        reported: Int?,
        currentRevision: Long
    ): Boolean = requested != null && reported != null &&
        currentRevision > revisionWhenRequested &&
        kotlin.math.abs(requested - reported) <= 1
}
