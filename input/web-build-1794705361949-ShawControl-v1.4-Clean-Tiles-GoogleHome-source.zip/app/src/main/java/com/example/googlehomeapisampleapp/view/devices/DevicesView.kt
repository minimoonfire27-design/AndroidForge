/* Copyright 2025 Google LLC

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package com.example.googlehomeapisampleapp.view.devices

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import com.example.googlehomeapisampleapp.FabricType
import com.example.googlehomeapisampleapp.R
import com.example.googlehomeapisampleapp.view.shared.TabbedMenuView
import com.example.googlehomeapisampleapp.viewmodel.HomeAppViewModel
import com.example.googlehomeapisampleapp.viewmodel.devices.DeviceViewModel
import com.example.googlehomeapisampleapp.viewmodel.structures.RoomViewModel
import com.example.googlehomeapisampleapp.viewmodel.structures.StructureViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.googlehomeapisampleapp.viewmodel.ota.OtaUiState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

const val TAG = "DevicesView"

/**
 * Composable for displaying the account button and overflow menu in the Devices view.
 *
 * @param homeAppVM The [HomeAppViewModel] providing the data and logic.
 * @param onNavigateToUserManagement Callback to navigate to the User Management screen.
 */
@Composable
fun DevicesAccountButton(homeAppVM: HomeAppViewModel,
                         onNavigateToUserManagement: () -> Unit = {},
                         onNavigateToPresenceSettings: () -> Unit = {}
) {
  val context = LocalContext.current
  var expanded by remember { mutableStateOf(false) }
  var structureSnapshotUuid by rememberSaveable { mutableStateOf<String?>(null) }
  /**
   * UI Row containing:
   * - Account Icon Button: triggers a permission request using PermissionsManager.
   * - Overflow Menu: opens a dropdown with a "Revoke Permissions" option.
   *
   * Selecting "Revoke Permissions" launches an intent to Google’s account management page for
   * manually revoking app access.
   */
  Row {
    IconButton(
      onClick = { homeAppVM.homeApp.permissionsManager.requestPermissions(isForceRefresh = true) },
      modifier = Modifier.size(48.dp).background(Color.Transparent),
    ) {
      Icon(
        imageVector = Icons.Default.AccountCircle,
        contentDescription = "",
        modifier = Modifier.fillMaxSize(),
        tint = MaterialTheme.colorScheme.primary,
      )
    }

    IconButton(onClick = { expanded = true }) {
      Icon(Icons.Default.MoreVert, contentDescription = "Menu")
    }

    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
      DropdownMenuItem(
        text = { Text("Revoke Permissions") },
        onClick = {
          expanded = false
          val intent =
            Intent(
              Intent.ACTION_VIEW,
              "https://myaccount.google.com/u/2/connections?utm_source=3p".toUri(),
            )
          context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        },
      )
      DropdownMenuItem(
        text = { Text("Google Sign-In") },
        onClick = { homeAppVM.signInWithGoogleAccount(context) },
      )
      DropdownMenuItem(
        text = { Text("Link GHP Playground") },
        onClick = {
          expanded = false
          homeAppVM.openCloudLinkingSheet()
        },
      )
      DropdownMenuItem(
        text = { Text("User Management") },
        onClick = {
          expanded = false
          onNavigateToUserManagement()
        }
      )
      DropdownMenuItem(
        text = { Text("Presence Settings") },
        onClick = {
          expanded = false
          onNavigateToPresenceSettings()
        }
      )
      DropdownMenuItem(
        text = { Text("Send Structure Snapshot") },
        onClick = {
          expanded = false
          homeAppVM.sendStructureSnapshot(
            onSnapshotCollected = { uuid -> structureSnapshotUuid = uuid }
          )
        }
      )
      val isMultifacetEnabled by homeAppVM.isMultifacetEnabled.collectAsStateWithLifecycle()
      DropdownMenuItem(
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
              checked = isMultifacetEnabled,
              onCheckedChange = null // Handled by DropdownMenuItem onClick
            )
            Text("Multifacet Mode", modifier = Modifier.padding(start = 8.dp))
          }
        },
        onClick = {
          homeAppVM.setMultifacetEnabled(!isMultifacetEnabled)
        }
      )
    }
  }
  structureSnapshotUuid?.let { uuid ->
    AlertDialog(
      onDismissRequest = { structureSnapshotUuid = null },
      title = { Text("Structure Snapshot UUID") },
      text = {
        Column {
          Text("Snapshot requested successfully with UUID:")
          Spacer(modifier = Modifier.height(8.dp))
          SelectionContainer {
            Text(
              text = uuid,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val clipboardManager = context.getSystemService(ClipboardManager::class.java)
            clipboardManager?.setPrimaryClip(ClipData.newPlainText("Structure Snapshot UUID", uuid))
            Toast.makeText(context, "UUID copied to clipboard", Toast.LENGTH_SHORT).show()
          }
        ) {
          Text("Copy UUID")
        }
      },
      dismissButton = { Button(onClick = { structureSnapshotUuid = null }) { Text("Close") } },
    )
  }
}

/**
 * Composable for displaying the Devices view, which shows a list of structures and devices.
 *
 * @param homeAppVM The [HomeAppViewModel] providing the data and logic.
 * @param onRequestCreateRoom Callback for requesting to create a new room.
 * @param onRequestRoomSettings Callback for requesting to view/edit room settings.
 * @param onRequestMoveDevice Callback for requesting to move a device to a different room.
 * @param onRequestAddHub Callback for requesting to add a new hub.
 * @param onNavigateToUserManagement Callback to navigate to the User Management screen.
 */
@Composable
fun DevicesView(
  homeAppVM: HomeAppViewModel,
  onRequestCreateRoom: () -> Unit = {},
  onRequestRoomSettings: (RoomViewModel) -> Unit = {},
  onRequestMoveDevice: (DeviceViewModel) -> Unit = {},
  onRequestAddHub: () -> Unit = {},
  onSearchHome: () -> Unit = {},
  onNavigateToUserManagement: () -> Unit = {},
  onNavigateToPresenceSettings: () -> Unit = {},
) {
  val scope: CoroutineScope = rememberCoroutineScope()

  val structureVMs: List<StructureViewModel> = homeAppVM.structureVMs.collectAsState().value
  val selectedStructureVM: StructureViewModel? =
    homeAppVM.selectedStructureVM.collectAsState().value
  val structureName: String =
    selectedStructureVM?.name ?: stringResource(R.string.devices_structure_loading)

  var structurePickerExpanded by remember { mutableStateOf(false) }
  var plusMenuExpanded by remember { mutableStateOf(false) }

  var isCommissioningMenuVisible by remember { mutableStateOf(false) }

  Column(modifier = Modifier.fillMaxHeight()) {
    DevicesTopBar(
      title = "",
      leftButton = {
        IconButton(onClick = { plusMenuExpanded = true }) {
          Icon(Icons.Default.Add, contentDescription = "Add")
        }
        DropdownMenu(expanded = plusMenuExpanded, onDismissRequest = { plusMenuExpanded = false }) {
          DropdownMenuItem(
            text = { Text("Add Room") },
            onClick = {
              plusMenuExpanded = false
              onRequestCreateRoom()
            },
          )
          DropdownMenuItem(
            text = { Text("Add Hub") },
            onClick = {
              plusMenuExpanded = false
              onRequestAddHub()
            },
          )
        }
      },
      rightButtons =
        listOf(
          {
            IconButton(onClick = onSearchHome, enabled = selectedStructureVM != null) {
              Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "Search Home")
            }
          },
          { DevicesAccountButton(homeAppVM, onNavigateToUserManagement, onNavigateToPresenceSettings) },
        ),
    )

    Box(modifier = Modifier.weight(1f)) {
      Column {
        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
          if (structureVMs.size > 1) {
            TextButton(onClick = { structurePickerExpanded = true }) {
              Text(text = "$structureName ▾", fontSize = 32.sp)
            }
          } else {
            TextButton(onClick = { structurePickerExpanded = true }) {
              Text(text = structureName, fontSize = 32.sp)
            }
          }
        }

        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
          Box {
            DropdownMenu(
              expanded = structurePickerExpanded,
              onDismissRequest = { structurePickerExpanded = false },
            ) {
              for (structure in structureVMs) {
                val presence by structure.presenceState.collectAsState()
                DropdownMenuItem(
                  text = { Text("${structure.name} ($presence)") },
                  onClick = {
                    homeAppVM.setSelectedStructure(structure)
                    structurePickerExpanded = false
                  },
                )
              }
            }
          }
        }

        Column(
          modifier =
            Modifier.verticalScroll(rememberScrollState()).weight(weight = 1f, fill = false)
        ) {
          DeviceListComponent(
            homeAppVM = homeAppVM,
            onRoomClick = onRequestRoomSettings,
            onDeviceLongPress = onRequestMoveDevice,
          )
        }
      }

      Box(modifier = Modifier.padding(16.dp).align(Alignment.BottomEnd)) {
        Button(onClick = { isCommissioningMenuVisible = true }) {
          Text(stringResource(R.string.devices_button_add))
        }
        DropdownMenu(
          expanded = isCommissioningMenuVisible,
          onDismissRequest = { isCommissioningMenuVisible = false },
        ) {
          DropdownMenuItem(
            text = { Text("Add Device to Google Fabric Only") },
            onClick = {
              isCommissioningMenuVisible = false
              homeAppVM.homeApp.commissioningManager.requestCommissioning(FabricType.GOOGLE_FABRIC)
            },
          )
          DropdownMenuItem(
            text = { Text("Add Device to Google & 3P Fabric") },
            onClick = {
              isCommissioningMenuVisible = false
              homeAppVM.homeApp.commissioningManager.requestCommissioning(
                FabricType.THIRD_PARTY_FABRIC
              )
            },
          )
          DropdownMenuItem(
            text = { Text("Add Google Camera") },
            onClick = {
              isCommissioningMenuVisible = false
              homeAppVM.onCommissionCamera()
            },
          )
        }
      }
    }

    TabbedMenuView(homeAppVM)
  }
}

/**
 * Composable for displaying a single device item in a list.
 *
 * @param deviceVM The [DeviceViewModel] for the device.
 * @param homeAppVM The [HomeAppViewModel] for navigation.
 * @param onLongPress Callback for when the device item is long-pressed.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DeviceListItem(
  deviceVM: DeviceViewModel,
  homeAppVM: HomeAppViewModel,
  onLongPress: (DeviceViewModel) -> Unit,
) {
  val scope: CoroutineScope = rememberCoroutineScope()
  val deviceStatus: String = deviceVM.status.collectAsState().value
  val deviceName: String = deviceVM.name.collectAsState().value

  val currentOtaUiState by homeAppVM.otaUiState.collectAsStateWithLifecycle(OtaUiState.Loading)
  val activeOtaDeviceId by homeAppVM.otaDeviceId.collectAsStateWithLifecycle()
  val activeOtaDeviceIds by homeAppVM.otaDeviceIds.collectAsStateWithLifecycle()

  val isThisDeviceUpdating = deviceVM.id == activeOtaDeviceId || activeOtaDeviceIds.contains(deviceVM.id)
  val otaUiState = if (isThisDeviceUpdating) currentOtaUiState else OtaUiState.UpToDate()

  LaunchedEffect(otaUiState) {
    if (otaUiState is OtaUiState.Downloading || otaUiState is OtaUiState.Installing) {
      Log.d("DevicesView", "DeviceListItem $deviceName active OTA state: $otaUiState")
    }
  }

  Column(
    Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
      .fillMaxWidth()
      .combinedClickable(
        onClick = { scope.launch { homeAppVM.selectedDeviceVM.emit(deviceVM) } },
        onLongClick = { onLongPress(deviceVM) },
      )
  ) {
    Text(deviceName, fontSize = 20.sp)
    Text(deviceStatus, fontSize = 16.sp)
    when (val state = otaUiState) {
      is OtaUiState.Downloading -> {
        val progress = state.progressPercent
        Text(
          text = if (progress != null) "Updating $progress%" else "Updating...",
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.primary
        )
      }
      is OtaUiState.Installing -> {
        Text(
          text = "Installing...",
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.primary
        )
      }
      else -> {}
    }
  }
}

/**
 * Composable for displaying a single room item in a list.
 *
 * @param roomVM The [RoomViewModel] for the room.
 * @param onClick Callback for when the room item is clicked.
 */
@Composable
fun RoomListItem(roomVM: RoomViewModel, onClick: (RoomViewModel) -> Unit) {
  val roomName by roomVM.name.collectAsState()

  Column(
    Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().clickable {
      onClick(roomVM)
    }
  ) {
    Text(roomName, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
  }
}

/**
 * Composable for displaying a list of devices, grouped by rooms.
 *
 * @param homeAppVM The [HomeAppViewModel] providing the data.
 * @param onRoomClick Callback for when a room is clicked.
 * @param onDeviceLongPress Callback for when a device is long-pressed.
 */
@Composable
fun DeviceListComponent(
  homeAppVM: HomeAppViewModel,
  onRoomClick: (RoomViewModel) -> Unit,
  onDeviceLongPress: (DeviceViewModel) -> Unit,
) {
  val selectedStructureVM: StructureViewModel =
    homeAppVM.selectedStructureVM.collectAsState().value ?: return

  val selectedRoomVMs: List<RoomViewModel> = selectedStructureVM.roomVMs.collectAsState().value

  val selectedDeviceVMsWithoutRooms: List<DeviceViewModel> =
    selectedStructureVM.deviceVMsWithoutRooms.collectAsState().value

  Column {
    for (roomVM in selectedRoomVMs) {
      RoomListItem(roomVM, onClick = onRoomClick)

      val deviceVMsInRoom: List<DeviceViewModel> = roomVM.deviceVMs.collectAsState().value

      for (deviceVM in deviceVMsInRoom) {
        DeviceListItem(deviceVM, homeAppVM, onLongPress = onDeviceLongPress)
      }
    }

    if (selectedDeviceVMsWithoutRooms.isNotEmpty()) {

      Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth()) {
        Text("Not in a room", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
      }

      for (deviceVM in selectedDeviceVMsWithoutRooms) {
        DeviceListItem(deviceVM, homeAppVM, onLongPress = onDeviceLongPress)
      }
    }
  }
}

/**
 * Composable for displaying the top bar of the Devices view.
 *
 * @param title The title to display in the top bar.
 * @param leftButton Optional Composable for a button on the left side of the top bar.
 * @param rightButtons List of Composable for buttons on the right side of the top bar.
 */
@Composable
fun DevicesTopBar(
  title: String,
  leftButton: (@Composable () -> Unit)? = null,
  rightButtons: List<@Composable () -> Unit>,
) {
  Box(Modifier.height(64.dp).fillMaxWidth().padding(horizontal = 16.dp)) {
    if (leftButton != null) {
      Row(
        Modifier.height(64.dp).fillMaxWidth().background(Color.Transparent),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start,
      ) {
        leftButton()
      }
    }

    Row(
      Modifier.height(64.dp).fillMaxWidth().background(Color.Transparent),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center,
    ) {
      Text(title, fontSize = 24.sp)
    }

    Row(
      Modifier.height(64.dp).fillMaxWidth().background(Color.Transparent),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.End,
    ) {
      for (button in rightButtons) {
        button()
      }
    }
  }
}
