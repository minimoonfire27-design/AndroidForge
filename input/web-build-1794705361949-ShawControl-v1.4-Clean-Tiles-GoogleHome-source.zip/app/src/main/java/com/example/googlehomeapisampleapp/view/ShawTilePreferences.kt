package com.example.googlehomeapisampleapp.view

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Local dashboard visibility only. Does not modify Google Home permissions or device state. */
internal class ShawTilePreferences(context: Context) {
    private val store = context.applicationContext.getSharedPreferences("shaw_dashboard", Context.MODE_PRIVATE)

    // Copy the set: SharedPreferences' returned StringSet must never be modified in place.
    var hiddenDeviceIds: Set<String> by mutableStateOf(
        store.getStringSet("hidden_device_ids_v1", emptySet())?.toSet() ?: emptySet()
    )
        private set

    fun isVisible(deviceId: String): Boolean = deviceId !in hiddenDeviceIds

    fun setVisible(deviceId: String, visible: Boolean) {
        val updated = if (visible) hiddenDeviceIds - deviceId else hiddenDeviceIds + deviceId
        if (updated == hiddenDeviceIds) return
        hiddenDeviceIds = updated
        store.edit().putStringSet("hidden_device_ids_v1", updated.toSet()).apply()
    }

    fun showAll() {
        hiddenDeviceIds = emptySet()
        store.edit().remove("hidden_device_ids_v1").apply()
    }
}
