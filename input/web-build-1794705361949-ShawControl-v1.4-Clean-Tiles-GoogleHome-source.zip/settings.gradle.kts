pluginManagement {
    repositories {
        mavenLocal()
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
@Suppress("UnstableApiUsage")
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        // Local maven (.m2) repository:
        maven { url = uri("home-sdk-repo") }
        mavenLocal()
        // Remote repositories:
        google()
        mavenCentral()
    }
}

rootProject.name = "Shaw Control - Google Home"
include(":app")
 