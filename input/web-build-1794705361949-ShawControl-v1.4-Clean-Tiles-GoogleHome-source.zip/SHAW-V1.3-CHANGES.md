# Shaw Control v1.3 — actual slow-cloud switch fix

## Root cause identified in v1.2

When the light was turned on, the dashboard switched to "waiting for reported state". It
then *disabled* ON/OFF until Google Home's `OnOff` stream confirmed the new value. Cloud
state sometimes lags or doesn't change, so the light could physically turn ON while its
control was stuck. After the 12-second timeout it would snap back to the stale OFF value,
preventing the user from tapping OFF.

## Implemented in v1.3

1. Separate requested state from Google-reported state. The switch shows the latest user
   request immediately; the label explicitly says unconfirmed when appropriate.
2. ON and OFF use explicit `on()` / `off()` calls; NEVER choose the next command based on
   a stale cloud reading, and never use the SDK's `toggle()` call.
3. Accept a reverse tap immediately while the first API call is still running. Queue
   only the most recent user-requested action and send it after the first call finishes,
   preserving order and avoiding overlapping ON/OFF calls.
4. No 12-second lock. The command phase ends when the command call returns or after an
   8-second API timeout; stale trait data does not disable the switch.
5. Add dedicated PowerReading / BrightnessReading StateFlows to the DeviceViewModel.
   The primitive state is observed independently from a List<Trait> that might compare
   equal and suppress Compose updates.
6. Use Google's live `device.types()` stream with bounded retry/backoff when it
   fails. New state is considered confirmed ONLY when a subsequent changed reading
   matches the requested state (not a cached value from before the command).
7. Exactly one optional post-command `forceRead()` (on a separate coroutine). It does
   not block controls. The manual "Refresh Google's state" action never resends power.
8. Brightness behaves similarly: user-requested level remains visible until a fresh
   report, and command requests are only sent after the slider drag ends.
9. PC power-off always requires explicit confirmation. No automatic command retries.
10. Log command response times under the `ShawControl.Commands` logcat tag and display
    the duration beneath each device. This measures API response, NOT physical action.
11. Skip unused automation/presence subscriptions on Shaw Control's dashboard
    and skip firmware-update observation for non-Matter devices, reducing Home
    API subscription load. Advanced sample automation/presence data isn't populated
    in this lightweight dashboard build.
12. Pure Kotlin reconciliation logic with 8 passing JVM checks in
    `tools/tests/ShawStateReconcilerTest.kt`.

## Known limitations

* Google's Home API / Tuya / Tapo cloud latency cannot be removed by app UI changes.
* This source has NOT been built into an APK or tested on the Samsung in this environment.
* AndroidForge may use a NEW debug signing cert every time. Google OAuth must register
  the resulting APK's Android package + signing SHA-1. Reusing a persistent PRIVATE
  signing key in your own build system is the lasting fix; never put it in a public ZIP.
* The Google Home SDK was separately supplied and may be subject to developer terms.
  Do NOT publish the included `home-sdk-repo` files to a public GitHub repository.
