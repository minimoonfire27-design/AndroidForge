# Shaw Control v1.4 — Clean Home Tiles

This ZIP is an Android Studio / Gradle **source project**, not an APK. It is based on the real Google Home API integration that was working in v1.3.

## What changed (only the requested UI/features)

- Replaced the long device-card list with a clean two-column **Home** tile grid.
- **Tap anywhere on a tile** to switch a compatible device ON/OFF — no little switch to aim for. A light-blue tile represents the last requested ON state; a white tile represents OFF.
- The tile label always shows the device name, with a short state underneath. When Google's cloud data is late, it says **Waiting for Google**, rather than pretending it has confirmed the command.
- Tap **•••** on a tile to reveal brightness (if supported), a read-only **Sync state** option, command timing and device details.
- Added an actual **Settings** tab where you can tick / untick the devices appearing on Home. Changes take effect immediately and persist on this phone using Android `SharedPreferences`, keyed by stable Google Home device ID.
- **Show all** restores hidden tiles. Hiding a tile only changes this app's Home screen; it does not disconnect devices from Google Home.
- Preserves the v1.3 fast reverse command handling, Google Home permission flow and important PC-plug power-off confirmation.

## Install / signing

The Android package is unchanged: `uk.co.shawcontrol.home`.
Version: `1.4.0-clean-tiles`, versionCode **5**.

**Use a private build setup.** This project includes separately distributed Google Home SDK library artifacts provided for your local project, so don't publish the ZIP or those SDK artifacts to a public GitHub repository.

AndroidForge has previously signed each APK with a DIFFERENT certificate. Android cannot update an existing same-package app if the new APK uses a different certificate; this produces `INSTALL_FAILED_UPDATE_INCOMPATIBLE`. Uninstalling deletes app data. Also, Google's Android OAuth client for Google Home must include the **SHA-1 of the exact APK** that you install, with package name `uk.co.shawcontrol.home`. Keep your existing Android OAuth clients rather than deleting them. Long term, use a fixed signing key managed securely in private CI / local Android Studio; never commit a keystore or passwords to a public repository.

## Quick sanity tests on your Samsung A13

1. Open Home and press Jamie's Light tile. Make sure it switches ON, then press again to turn it OFF, even if Google is still confirming.
2. Open **Settings**, untick Desk, return Home: Desk should disappear. Re-enable it: it should reappear without reconnecting Google Home. Close and reopen the app to test persistence.
3. Tap the tile's **•••** for brightness and state sync; the whole main tile remains the power button.
4. For the PC plug, make sure tapping from ON to OFF still brings up a safety warning. Don't cut the PC's electricity while Windows is running.

## Diagnostics (same as every release)

Before testing, run:

    "C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -c

After reproducing an error, run:

    "C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -d -v time > "%USERPROFILE%\Desktop\shaw-error.txt"

For logs that disappear, run a live capture *before* reproducing, stop with Ctrl+C:

    "C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -v time > "%USERPROFILE%\Desktop\shaw-live-error.txt"

Android logs may contain personal details: share privately, don't publish raw full logs.

## Test status

Source reviewed and Kotlin parser checked. Existing state reconciliation checks pass. **No full Android build or physical Google Home test has been performed in this environment**, so the ZIP should be treated as build-ready source, not a verified running APK.
