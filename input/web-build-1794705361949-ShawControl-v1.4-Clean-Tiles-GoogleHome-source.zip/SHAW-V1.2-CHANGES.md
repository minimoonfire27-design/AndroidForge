# Shaw Control v1.2 — state sync patch

- Switch visually follows requested state instantly **while clearly labelled unconfirmed**.
- Incoming Google Home trait stream remains source of truth.
- After a successful power or brightness command, request one targeted `forceRead()` for new state.
- Add manual Sync state per card; it reads state, **never re-sends the power command**.
- Avoid repeated cloud toggles and full home refreshes.
- Confirmation wait increased to 12 seconds; warn rather than report false success or retry.
- Brightness holds requested value temporarily until confirmed or timed out.
- PC plug power-off safety dialogue retained.

This is source code, not a built/tested APK. Google Home transport delays cannot be eliminated by app code. Google Cloud OAuth SHA-1 must match the signing certificate of the new APK. Please keep proprietary Google Home SDK files private and never publish this archive.
