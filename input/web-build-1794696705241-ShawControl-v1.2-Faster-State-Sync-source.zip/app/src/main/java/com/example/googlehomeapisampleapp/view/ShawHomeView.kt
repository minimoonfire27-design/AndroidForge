package com.example.googlehomeapisampleapp.view

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.googlehomeapisampleapp.AccountSwitchProxyActivity
import com.example.googlehomeapisampleapp.viewmodel.HomeAppViewModel
import com.example.googlehomeapisampleapp.viewmodel.devices.DeviceViewModel
import com.google.home.matter.standard.OnOff
import com.google.home.matter.standard.LevelControl
import com.google.home.matter.standard.LevelControlTrait
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException

private val Night = Color(0xFF0B1422)
private val Panel = Color(0xFF17253A)
private val Sky = Color(0xFF72B6FF)
private val Pale = Color(0xFFB0C1D7)

@Composable
fun ShawHomeView(vm: HomeAppViewModel) {
    val signedIn by vm.homeApp.permissionsManager.isSignedIn.collectAsState()
    val structure by vm.selectedStructureVM.collectAsState()
    val selectedDevice by vm.selectedDeviceVM.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        vm.navigateToProxyActivity.collect {
            val intent = Intent(context, AccountSwitchProxyActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            context.startActivity(intent)
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Sky, background = Night, surface = Panel)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Night) {
            if (!signedIn) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(26.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Shaw Control", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(10.dp))
                    Text("Your home, one connection.", fontSize = 16.sp, color = Pale)
                    Spacer(Modifier.height(40.dp))
                    Button(
                        onClick = { vm.signInWithGoogleAccount(context) },
                        modifier = Modifier.fillMaxWidth().height(58.dp)
                    ) { Text("Connect Google Home", fontSize = 17.sp) }
                    Spacer(Modifier.height(12.dp))
                    TextButton(onClick = { vm.homeApp.permissionsManager.requestPermissions() }) {
                        Text("Already signed in? Grant access")
                    }
                    Spacer(Modifier.height(15.dp))
                    Text("Google will ask which home and devices to share. Your password stays with Google.",
                        fontSize = 13.sp, color = Pale)
                }
            } else if (selectedDevice != null) {
                // Retain Google's real device-detail controls, including supported traits.
                com.example.googlehomeapisampleapp.view.devices.DeviceView(vm)
            } else {
                val selectedRooms = structure?.roomVMs?.collectAsState()?.value.orEmpty()
                val unassigned = structure?.deviceVMsWithoutRooms?.collectAsState()?.value.orEmpty()
                Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    Spacer(Modifier.height(37.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Shaw Control", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            Text(structure?.name ?: "Loading your Google Home…", color = Pale, fontSize = 14.sp)
                        }
                        TextButton(onClick = { vm.homeApp.permissionsManager.requestPermissions(isForceRefresh = true) }) {
                            Text("Access")
                        }
                    }
                    Spacer(Modifier.height(19.dp))
                    Column(Modifier.verticalScroll(rememberScrollState()).fillMaxWidth()) {
                        if (structure == null) {
                            Text("Your home is loading. Check your Google Home permissions if no devices appear.", color = Pale)
                        }
                        selectedRooms.forEach { room ->
                            Text(room.name.collectAsState().value, color = Pale,
                                modifier = Modifier.padding(top = 17.dp, bottom = 7.dp, start = 4.dp))
                            room.deviceVMs.collectAsState().value.forEach { device ->
                                ShawDeviceCard(device) { scope.launch { vm.selectedDeviceVM.emit(device) } }
                            }
                        }
                        if (unassigned.isNotEmpty()) {
                            Text("Other devices", color = Pale, modifier = Modifier.padding(top = 17.dp, bottom = 7.dp))
                            unassigned.forEach { device ->
                                ShawDeviceCard(device) { scope.launch { vm.selectedDeviceVM.emit(device) } }
                            }
                        }
                        Spacer(Modifier.height(25.dp))
                        Text("Controls are synced through Google's Home APIs. Some device types may not expose every feature.",
                            fontSize = 12.sp, color = Pale)
                        Spacer(Modifier.height(30.dp))
                    }
                }
            }
        }
    }
}

/**
 * Controls intentionally have no automatic retries: a timed-out/offline smart plug may
 * still act on an old command, and replaying it would be dangerous (especially the PC plug).
 */
@Composable
private fun ShawDeviceCard(vm: DeviceViewModel, onOpen: () -> Unit) {
    val name by vm.name.collectAsState()
    val status by vm.status.collectAsState()
    val traits by vm.traits.collectAsState()
    val scope = rememberCoroutineScope()
    val onOff = traits.filterIsInstance<OnOff>().firstOrNull()
    val level = traits.filterIsInstance<LevelControl>().firstOrNull()
    val observedOn = onOff?.onOff == true
    val observedLevel = level?.currentLevel?.toFloat()?.coerceIn(0f, 254f)

    var sendingPower by remember(vm.id) { mutableStateOf(false) }
    var waitingForPowerState by remember(vm.id) { mutableStateOf<Boolean?>(null) }
    var waitingTooLong by remember(vm.id) { mutableStateOf(false) }
    var powerMessage by remember(vm.id) { mutableStateOf<String?>(null) }
    var syncingState by remember(vm.id) { mutableStateOf(false) }
    var confirmPcOff by remember(vm.id) { mutableStateOf(false) }
    var brightness by remember(vm.id) { mutableFloatStateOf(observedLevel ?: 0f) }
    var editingBrightness by remember(vm.id) { mutableStateOf(false) }
    var sendingBrightness by remember(vm.id) { mutableStateOf(false) }
    var brightnessMessage by remember(vm.id) { mutableStateOf<String?>(null) }
    var targetBrightness by remember(vm.id) { mutableStateOf<Int?>(null) }

    // Google Home state is authoritative: the switch is not marked as confirmed ON/OFF
    // just because a request returned without throwing.
    LaunchedEffect(observedOn, waitingForPowerState) {
        if (waitingForPowerState == observedOn) {
            waitingForPowerState = null
            waitingTooLong = false
            powerMessage = null
        }
    }
    // Do not leave the switch disabled indefinitely when a device stops reporting state.
    // The UI warns rather than silently resending a command.
    LaunchedEffect(waitingForPowerState) {
        if (waitingForPowerState != null) {
            delay(12000)
            if (waitingForPowerState != null) {
                waitingTooLong = true
                waitingForPowerState = null
                powerMessage = "No confirmed update after 12 seconds. Check the device, then tap Sync state. No command was resent."
            }
        }
    }
    LaunchedEffect(observedLevel, editingBrightness, sendingBrightness, targetBrightness) {
        if (observedLevel != null && targetBrightness != null &&
            kotlin.math.abs(observedLevel.toInt() - targetBrightness!!) <= 1) {
            targetBrightness = null
            brightnessMessage = null
        }
        if (!editingBrightness && !sendingBrightness && targetBrightness == null && observedLevel != null) {
            brightness = observedLevel
        }
    }
    LaunchedEffect(targetBrightness) {
        if (targetBrightness != null) {
            delay(12000)
            if (targetBrightness != null) {
                targetBrightness = null
                brightnessMessage = "Brightness hasn't been confirmed yet. Sync state to check."
            }
        }
    }

    // Read the state again; NEVER repeat the power command on a timeout.
    fun syncState() {
        if (onOff == null || syncingState) return
        syncingState = true
        scope.launch {
            try {
                onOff.forceRead()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                powerMessage = "Sync failed: ${e.message?.take(100) ?: "device unavailable"}"
            } finally {
                syncingState = false
            }
        }
    }

    fun toggle(next: Boolean) {
        if (onOff == null || sendingPower || waitingForPowerState != null) return
        if (observedOn == next) return
        sendingPower = true
        waitingTooLong = false
        powerMessage = null
        // Immediately show a working state; don't claim success before a real state update.
        waitingForPowerState = next
        scope.launch {
            try {
                if (next) onOff.on() else onOff.off()
                // A successful command response does not guarantee that the Home API
                // has emitted a fresh state. Request one targeted read instead of
                // reloading every room/device or replaying the command.
                delay(300)
                runCatching { onOff.forceRead() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                waitingForPowerState = null
                powerMessage = e.message?.take(160) ?: "Command failed. Please try again."
            } finally {
                sendingPower = false
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable(onClick = onOpen)) {
                    Text(name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    val waiting = waitingForPowerState != null
                    Text(
                        when {
                            sendingPower -> "Sending command…"
                            waiting -> "Waiting for device to confirm…"
                            else -> status
                        }, color = Pale, fontSize = 12.sp
                    )
                }
                if (onOff != null) {
                    if (sendingPower || waitingForPowerState != null) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp).padding(end = 2.dp),
                            strokeWidth = 2.dp,
                            color = Sky
                        )
                        Spacer(Modifier.width(12.dp))
                    }
                    Switch(
                        // Immediate interaction feedback, but the label explicitly marks
                        // the state as unconfirmed until the Home API reports a change.
                        checked = waitingForPowerState ?: observedOn,
                        onCheckedChange = { value ->
                            if (!value && name.contains("pc", ignoreCase = true)) confirmPcOff = true
                            else toggle(value)
                        },
                        enabled = !sendingPower && waitingForPowerState == null
                    )
                } else {
                    Text("Details", color = Sky, modifier = Modifier.clickable(onClick = onOpen))
                }
            }
            if (waitingForPowerState != null) {
                Text("Requested ${if (waitingForPowerState == true) "ON" else "OFF"} · awaiting confirmation", color = Sky, fontSize = 12.sp)
            }
            if (powerMessage != null || waitingTooLong) {
                Spacer(Modifier.height(7.dp))
                Text(powerMessage ?: "", color = Color(0xFFFFB0A4), fontSize = 12.sp)
            }
            if (observedLevel != null && level != null) {
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Brightness ${(brightness * 100f / 254f).toInt()}%", color = Pale, fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                    if (sendingBrightness) {
                        Text("Sending…", color = Sky, fontSize = 12.sp)
                    }
                }
                Slider(
                    value = brightness,
                    onValueChange = { brightness = it; editingBrightness = true },
                    valueRange = 0f..254f,
                    enabled = !sendingBrightness,
                    onValueChangeFinished = {
                        editingBrightness = false
                        val chosen = brightness.toInt().coerceIn(0, 254)
                        // One request per completed drag; never spam cloud commands while dragging.
                        if (!sendingBrightness && kotlin.math.abs(chosen - (observedLevel.toInt())) >= 1) {
                            sendingBrightness = true
                            targetBrightness = chosen
                            brightnessMessage = null
                            scope.launch {
                                try {
                                    level.moveToLevelWithOnOff(
                                        level = chosen.toUByte(), transitionTime = null,
                                        optionsMask = LevelControlTrait.OptionsBitmap(),
                                        optionsOverride = LevelControlTrait.OptionsBitmap()
                                    )
                                    delay(300)
                                    runCatching { level.forceRead() }
                                } catch (e: CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    targetBrightness = null
                                    brightnessMessage = e.message?.take(160) ?: "Brightness command failed."
                                } finally {
                                    sendingBrightness = false
                                }
                            }
                        }
                    }
                )
                if (targetBrightness != null) {
                    Text("Awaiting brightness confirmation…", color = Sky, fontSize = 12.sp)
                }
                if (brightnessMessage != null) {
                    Text(brightnessMessage ?: "", color = Color(0xFFFFB0A4), fontSize = 12.sp)
                }
            }
            if (onOff != null) {
                TextButton(onClick = { syncState() }, enabled = !syncingState && !sendingPower) {
                    Text(if (syncingState) "Syncing…" else "Sync state", fontSize = 12.sp)
                }
            }
        }
    }
    if (confirmPcOff) {
        AlertDialog(
            onDismissRequest = { confirmPcOff = false },
            title = { Text("Switch off PC plug?") },
            text = { Text("This immediately cuts electricity. Shut Windows down first. The app will not retry this command automatically.") },
            confirmButton = { TextButton(onClick = { confirmPcOff = false; toggle(false) }) { Text("Switch off") } },
            dismissButton = { TextButton(onClick = { confirmPcOff = false }) { Text("Cancel") } }
        )
    }
}
