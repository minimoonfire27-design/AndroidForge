# v1.6 — smooth animations, keep awake, quieter and more responsive controls

See README-V1.6-FIRST.md for the full changelog, Android 1x animation commands and logcat/installation commands.

**Validation:** compile-independent state reconciliation test; static source checks. Full Android build and real Google Home device testing not available here.
