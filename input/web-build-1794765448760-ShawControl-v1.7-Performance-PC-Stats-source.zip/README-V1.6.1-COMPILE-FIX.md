# Shaw Control v1.6.1 — Kotlin build fix

This is the original v1.6 Smooth & Fast source with **only two Kotlin compile errors fixed** in `app/src/main/java/com/example/googlehomeapisampleapp/view/ShawHomeView.kt`.

- Line 542: `powerReading.value.value` -> `powerReading.value`
- Line 703: `brightnessReading.value.value` -> `brightnessReading.value`

Why: `powerReading` and `brightnessReading` have already been unwrapped by Compose's `collectAsState()` delegate, and represent `PowerReading`/`BrightnessReading` instances. Each has one `value` field. The extra access accidentally resolves to Material3 `value` candidates and fails Kotlin compilation. The two `.value.value` expressions in `DeviceViewModel.kt` are correct because they operate on the `MutableStateFlow` directly and were intentionally left alone.

No functional design or Google Home/OAuth changes. Rebuild this complete source ZIP in AndroidForge.

This correction was reviewed against the model class declarations and the eight standalone Kotlin state-reconciliation checks. A full Android Gradle build and device test were not available in this environment.

Important: AndroidForge may use a fresh signing certificate for each build, which can cause UPDATE_INCOMPATIBLE and require a matching SHA-1 in the Google Cloud Android OAuth client. Keep your old APK until the new one is installed and working. Do not upload Google's separately distributed SDK binaries to a public repository.
