# Shaw Control v1.7 — Faster navigation + local PC Stats

Built on the working Shaw Control v1.6.2 Google Home source.

## App changes

- A dedicated **PC Stats** tab appears only after enabling it under Settings → PC monitoring.
- Read live CPU usage, CPU temperature, GPU usage, GPU temperature, RAM usage and RAM in use when Libre Hardware Monitor exposes those sensors.
- Refreshes every ~2 seconds **only while you are viewing the PC Stats tab**. No spacedesk, screen streaming, or continuous background polling.
- Fast offline detection: clears stale readings when the PC isn't answering and displays PC Offline.
- Restricts PC monitoring to IPv4 addresses on the local private network; does not contact public IPs.
- Settings device entries are now in a lazy list, avoiding building every tile-size selector on every tab switch.
- Removed broad layout-size animations from Google device cards; preserves quick colour transitions and PC plug power-off confirmation.
- Only observes a Google Home device's status text if the device lacks a working OnOff control, reducing unnecessary card updates.
- Existing Google OAuth connection and device-control code remain in place.

## Configure Windows once

1. Download official Libre Hardware Monitor from: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases
2. Open LibreHardwareMonitor.exe (run as administrator if some sensors are missing).
3. Enable **Options → Remote Web Server → Run**. Default port is **8085**.
4. Enable **Options → Run On Windows Startup** and **Start Minimized** / **Minimize To Tray** if available in your version. Normal Windows startup happens after signing in, not before.
5. Open Windows Command Prompt and run `ipconfig`. Find your active Wi-Fi or Ethernet adapter and copy **IPv4 Address** (for example, 192.168.1.123). Do **not** use the Default Gateway, 127.0.0.1, or your public IP.
6. Test from a browser on the PC: `http://127.0.0.1:8085/data.json` (should display sensor JSON).
7. Allow **TCP port 8085** only on your **Private** Windows network. If you need to create a manual firewall rule, run an Administrator CMD:
   `netsh advfirewall firewall add rule name="Shaw Control PC Stats" dir=in action=allow protocol=TCP localport=8085 profile=private remoteip=localsubnet`
8. Test from a browser on the Samsung while on the same Wi-Fi: `http://YOUR-PC-IP:8085/data.json`. If it fails, the PC server or private-network firewall is not reachable; Shaw Control cannot fix that from Android.
9. In Shaw Control → Settings → PC monitoring, turn on the PC Stats tab and enter that exact IPv4 address. Open the PC Stats tab. When the PC is off or you stop the server, you'll see **PC Offline**.
10. For reliable reconnection after restarts, reserve the PC's local IP in your router's DHCP settings. Don't port-forward 8085 on the router.

**Security:** The Libre Hardware Monitor server uses plain HTTP by default. Restrict it to the trusted home network; never expose it to the internet. This app's PC monitor only supports an unauthenticated, private-LAN endpoint. If you enable HTTP basic auth in LHM, this app will not connect. Use a trusted, isolated home network instead.

## Android build

The source project includes user-supplied, separately distributed Google Home SDK libraries. Keep this source ZIP and those SDKs **private**; do not push them to public GitHub repositories without checking the Google SDK terms.

- Version: 1.7.0-performance-pc-stats
- App package ID: `uk.co.shawcontrol.home`
- The build's Google OAuth SHA-1 is determined by the signing certificate of the **built APK**, not this source ZIP. AndroidForge has previously generated a new key per build.
- A full Android Gradle build and physical Samsung test were not available in this environment. The standalone state-reconciliation Kotlin tests, PC sensor parser/LAN tests, and manifest checks passed.

## ADB commands after each new APK

Install (replace filename if your download gets renamed):
`"C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" install -r "%USERPROFILE%\Downloads\AndroidForge-app-debug.apk"`

Launch:
`"C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" shell monkey -p uk.co.shawcontrol.home 1`

Clear logs **before** reproducing an error:
`"C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -c`

Save logs **after** reproducing it:
`"C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -d -v time > "%USERPROFILE%\Desktop\shaw-error.txt"`

If installation says `INSTALL_FAILED_UPDATE_INCOMPATIBLE`, **do not uninstall your current working version** unless you understand this loses the app's saved settings. A stable signing key should be configured for later updates.
