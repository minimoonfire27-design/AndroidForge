# Shaw Control v1.6 — Smooth & Fast

**Version:** 1.6.0-smooth-fast (`uk.co.shawcontrol.home`, versionCode 7)

## What changed since v1.5

- The ***Device details*** button is gone from each tile’s ⋯ menu. The dashboard no longer routes to the bulky separate details screen. Unsupported devices cannot be toggled; the tile stays inactive.
- Smooth tile colour and text transitions; the extra-controls panel expands/collapses with animation. Android’s animation-scale developer setting controls these animations: if you previously set it to zero, restore it to 1x.
- **Settings → Appearance → Keep screen awake** is enabled by default. While Shaw Control is the foreground app, Android’s `FLAG_KEEP_SCREEN_ON` keeps the display awake. It stops working when the app is not foreground and does not run a background service. Disable it in Settings to save battery and reduce static-screen wear.
- Power and brightness commands as well as force-read operations are dispatched on `Dispatchers.IO` rather than tying up the UI coroutine dispatcher.
- No automatic fresh read after every successful command. State subscriptions are primary; a single bounded 1.5-second-delayed fallback read is attempted only if the observed value remains stale. This never repeats the original ON/OFF request and does not block a new button press.
- After a tap the home tile shows the requested ON/OFF state immediately. A timeout or command exception still produces a visible warning.
- Existing theme choices, tile order, size, visibility, brightness slider, reverse-command queue and PC plug OFF confirmation remain.

**RAM:** 40 MB is not a fixed cap. Android manages RAM for the app based on actual allocation and available memory. Forcing RAM use or clearing free RAM is not a safe way to make Google Home commands faster. No artificial memory target was added.

**Timing limit:** Google Home and smart-device networking may still be slow. A smoother UI is not proof that the physical device has confirmed the action. The displayed requested state and the reported state remain separate.

## Restore normal Samsung animations (do this on the PC once)

The commands below reset Android animation scales to the standard **1×**. They change phone settings, not Shaw Control code.

```cmd
"C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" shell settings put global window_animation_scale 1.0
"C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" shell settings put global transition_animation_scale 1.0
"C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" shell settings put global animator_duration_scale 1.0
```

Alternative: Samsung Settings → Developer options → set Window animation scale, Transition animation scale, and Animator duration scale to **1x**.

## Build & install

Build this ZIP privately using your established build process. **This is an Android source ZIP, not a compiled APK.** The bundled Home SDK is a separately distributed Google SDK. **Do not publish the SDK files in a public GitHub repository.** A full Gradle Android build and device test could not be done in this environment; this project is not guaranteed to compile or to be faster on-device without testing.

Use the **actual filename** AndroidForge saves in Downloads; don't assume an auto-numbered name.

```cmd
"C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" install -r "C:\Users\minim\Downloads\YOUR-NEW-FILE.apk"
"C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" shell monkey -p uk.co.shawcontrol.home 1
```

If Android says `INSTALL_FAILED_UPDATE_INCOMPATIBLE`, **don't immediately uninstall**. AndroidForge has previously changed signing keys. A different key would erase app preferences on uninstall and may require a matching Android OAuth client in Google Cloud. Check the new APK's signing SHA-1 before touching OAuth settings. **Never reuse a previous APK fingerprint without checking.**

## Error log commands (include after every APK)

Clear logs **before** reproducing the problem:

```cmd
"C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -c
```

Save **after** the problem:

```cmd
"C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -d -v time > "%USERPROFILE%\Desktop\shaw-error.txt"
```

These logs may contain private information. Review before posting elsewhere. For your first test use **Jamie's Light**, not the plug powering a running PC.
