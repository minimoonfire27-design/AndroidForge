# Version 1.5: UI personalisation and quiet state handling

Files changed:

- `app/src/main/java/com/example/googlehomeapisampleapp/view/ShawAppearance.kt` — new persisted theme, accent/background colour palettes and dark/light modes
- `app/src/main/java/com/example/googlehomeapisampleapp/view/ShawTilePreferences.kt` — new persisted order, size and previous visibility
- `app/src/main/java/com/example/googlehomeapisampleapp/view/ShawHomeView.kt` — theme-aware dashboard/settings, per-tile size, sort arrows, quiet status messages
- `app/build.gradle.kts` — versionCode 6 / versionName 1.5.0-custom-home

Existing Google Home SDK integration, credential flow, command handling and PC plug confirmation have not been replaced.

The normal tile subtitle shows On/Off after an accepted API command even if Google's last reported trait value is stale. An accepted API response does not prove the physical device changed; a manual Sync action remains available under the tile's extra controls. Network timeouts/errors still show warnings.
