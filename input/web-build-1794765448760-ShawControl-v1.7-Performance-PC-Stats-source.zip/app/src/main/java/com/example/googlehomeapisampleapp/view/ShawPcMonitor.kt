package com.example.googlehomeapisampleapp.view

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.coroutines.coroutineContext

/** Never contacts a public address; the PC monitor is strictly LAN-only. */
internal class ShawPcPreferences(context: Context) {
    private val store = context.applicationContext.getSharedPreferences("shaw_pc_monitor", Context.MODE_PRIVATE)
    var enabled by mutableStateOf(store.getBoolean("enabled_v1", false))
        private set
    var host by mutableStateOf(store.getString("host_v1", "") ?: "")
        private set

    fun setEnabled(value: Boolean) {
        enabled = value
        store.edit().putBoolean("enabled_v1", value).apply()
    }
    fun setHost(value: String) {
        host = value.take(64).trim()
        store.edit().putString("host_v1", host).apply()
    }
}

/** Accept only RFC1918 LAN IPv4; do not proxy public Internet or arbitrary URLs. */
internal fun isPrivatePcAddress(host: String): Boolean {
    val octets = host.trim().split('.')
    if (octets.size != 4) return false
    val nums = octets.map { part ->
        if (part.isEmpty() || part.length > 3 || !part.all { it in '0'..'9' }) null
        else part.toIntOrNull()?.takeIf { it in 0..255 }
    }
    if (nums.any { it == null }) return false
    val a = nums[0] ?: return false
    val b = nums[1] ?: return false
    return (a == 10 || (a == 172 && b in 16..31) || (a == 192 && b == 168)) &&
        nums[3] != 0 && nums[3] != 255
}

internal data class ShawPcStat(val label: String, val reading: String, val fraction: Float? = null)
internal data class ShawPcSnapshot(val stats: List<ShawPcStat>, val computer: String)

/** No background service: one bounded HTTP GET, only while PC Stats is visible. */
internal object ShawPcMonitor {
    suspend fun fetch(host: String): ShawPcSnapshot = withContext(Dispatchers.IO) {
        require(isPrivatePcAddress(host)) { "Enter your PC's local IPv4 address (for example 192.168.1.123)." }
        val connection = URL("http://$host:8085/data.json").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 1300
            connection.readTimeout = 1300
            connection.useCaches = false
            connection.setRequestProperty("Accept", "application/json")
            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                error("PC monitor returned HTTP ${connection.responseCode}")
            }
            val json = connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                val body = CharArray(160 * 1024)
                val text = StringBuilder()
                while (true) {
                    val count = reader.read(body)
                    if (count < 0) break
                    if (text.length + count > 256 * 1024) error("Sensor response too large")
                    text.append(body, 0, count)
                }
                text.toString()
            }
            parse(JSONObject(json))
        } finally {
            connection.disconnect()
        }
    }

    private data class Sensor(
        val name: String,
        val value: String,
        val type: String,
        val hardware: String,
        val path: String
    )
    private data class Candidate(val priority: Int, val sensor: Sensor)

    /** Handle both older and newer LibreHardwareMonitor data.json sensor trees. */
    fun parse(root: JSONObject): ShawPcSnapshot {
        val sensors = ArrayList<Sensor>()
        fun walk(node: JSONObject, hardware: String, ancestors: String, depth: Int) {
            if (depth > 16 || sensors.size > 2500) return
            val name = node.optString("Text", "")
            val hw = node.optString("HardwareId", "").ifBlank { hardware }
            val id = node.optString("SensorId", "")
            val path = (ancestors + " " + name + " " + hw + " " + id).lowercase(Locale.ROOT)
            val type = node.optString("Type", "")
            val raw = node.optString("RawValue", "").trim()
            val shown = node.optString("Value", "").trim()
            if (type.isNotEmpty() || id.isNotEmpty()) {
                val reading = shown.ifEmpty { raw }
                if (reading.isNotEmpty() && reading != "-" && reading != "NaN") {
                    sensors.add(Sensor(name, reading, type.lowercase(Locale.ROOT), hw, path))
                }
            }
            val children = node.optJSONArray("Children") ?: JSONArray()
            for (i in 0 until children.length()) {
                val child = children.optJSONObject(i) ?: continue
                walk(child, hw, (ancestors + " " + name).takeLast(280), depth + 1)
            }
        }
        walk(root, "", "", 0)
        fun isCpu(s: Sensor) = s.path.contains("/cpu/") || s.path.contains("/intelcpu/") ||
            s.path.contains("/amdcpu/") || s.path.contains("intel core") || s.path.contains("amd ryzen") ||
            s.path.contains("cpu [")
        fun isGpu(s: Sensor) = s.path.contains("/gpu") || s.path.contains("/nvidiagpu") ||
            s.path.contains("nvidia") || s.path.contains("geforce") || s.path.contains("radeon")
        fun isRam(s: Sensor) = s.path.contains("/ram/") || s.path.contains("/memory/") ||
            s.path.contains(" physical memory") || s.path.contains(" generic memory")
        fun match(kind: String, group: (Sensor) -> Boolean): Sensor? {
            val options = sensors.filter(group).mapNotNull { s ->
                val n = s.name.lowercase(Locale.ROOT)
                val t = s.type
                val priority = when (kind) {
                    "cpuLoad" -> if (t != "load" && !s.value.contains('%')) -1
                        else when { n == "cpu total" || n == "total" -> 100; n.contains("total") -> 85; n.contains("average") -> 75; else -> -1 }
                    "cpuTemp" -> if (t != "temperature" && !s.value.contains('°')) -1
                        else when { n.contains("package") -> 100; n.contains("core average") -> 95; n.contains("tctl") -> 92; n.contains("cpu") -> 80; else -> 50 }
                    "gpuLoad" -> if (t != "load" && !s.value.contains('%')) -1
                        else when { n == "gpu core" || n == "gpu total" -> 100; n == "gpu" -> 90; n.contains("gpu core") -> 85; n.contains("gpu") && !n.contains("memory") && !n.contains("video") -> 70; else -> -1 }
                    "gpuTemp" -> if (t != "temperature" && !s.value.contains('°')) -1
                        else when { n == "gpu core" -> 100; n.contains("gpu core") -> 90; n.contains("hot spot") -> 75; n.contains("gpu") -> 70; else -> -1 }
                    "ramLoad" -> if (t != "load" && !s.value.contains('%')) -1
                        else when { n.contains("memory") -> 100; n.contains("ram") -> 90; n.contains("total") -> 70; else -> -1 }
                    "ramUsed" -> if (t != "data" && !s.value.contains("GB") && !s.value.contains("MB")) -1
                        else when { n.contains("memory used") || n.contains("used memory") -> 100; n.contains("used") -> 80; else -> -1 }
                    "ramAvailable" -> if (t != "data" && !s.value.contains("GB") && !s.value.contains("MB")) -1
                        else when { n.contains("memory available") || n.contains("available memory") -> 100; n.contains("available") -> 80; else -> -1 }
                    else -> -1
                }
                if (priority >= 0) Candidate(priority, s) else null
            }
            return options.maxByOrNull { it.priority }?.sensor
        }
        fun numeric(s: Sensor?): Double? {
            if (s == null) return null
            val m = Regex("-?\\d+(?:[.,]\\d+)?").find(s.value) ?: return null
            return m.value.replace(',', '.').toDoubleOrNull()
        }
        fun pct(s: Sensor?): ShawPcStat? {
            val n = numeric(s)?.coerceIn(0.0, 100.0) ?: return null
            return ShawPcStat("", "${"%.0f".format(Locale.US, n)}%", (n / 100.0).toFloat())
        }
        fun temp(s: Sensor?): ShawPcStat? {
            val n = numeric(s) ?: return null
            return ShawPcStat("", "${"%.1f".format(Locale.US, n)}°C")
        }
        val stats = ArrayList<ShawPcStat>()
        fun add(label: String, candidate: ShawPcStat?) {
            if (candidate != null) stats.add(candidate.copy(label = label))
        }
        add("CPU usage", pct(match("cpuLoad", ::isCpu)))
        add("CPU temperature", temp(match("cpuTemp", ::isCpu)))
        add("GPU usage", pct(match("gpuLoad", ::isGpu)))
        add("GPU temperature", temp(match("gpuTemp", ::isGpu)))
        add("RAM usage", pct(match("ramLoad", ::isRam)))
        val used = match("ramUsed", ::isRam)
        val available = match("ramAvailable", ::isRam)
        if (used != null) {
            val v = numeric(used)
            if (v != null) {
                val unit = if (used.value.contains("MB", ignoreCase = true)) "MB" else "GB"
                val usedGb = if (unit == "MB") v / 1024.0 else v
                val availGb = numeric(available)?.let { a ->
                    if (available?.value?.contains("MB", ignoreCase = true) == true) a / 1024.0 else a
                }
                val detail = if (availGb != null) "${"%.1f".format(Locale.US, usedGb)} / ${"%.1f".format(Locale.US, usedGb + availGb)} GB"
                             else "${"%.1f".format(Locale.US, usedGb)} GB"
                add("RAM in use", ShawPcStat("", detail))
            }
        }
        val computer = root.optJSONArray("Children")?.optJSONObject(0)?.optString("Text") ?: "Windows PC"
        return ShawPcSnapshot(stats, computer.take(80))
    }
}

@Composable
internal fun ShawPcSettings(prefs: ShawPcPreferences) {
    val colors = LocalShawPalette.current
    Surface(shape = RoundedCornerShape(22.dp), color = colors.surface) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text("PC monitoring", color = colors.ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Text("Live Windows stats over your Wi-Fi. No spacedesk required.", color = colors.muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Show PC Stats tab", modifier = Modifier.weight(1f), color = colors.ink, fontSize = 14.sp)
                Switch(checked = prefs.enabled, onCheckedChange = prefs::setEnabled)
            }
            OutlinedTextField(
                value = prefs.host,
                onValueChange = prefs::setHost,
                label = { Text("PC IPv4 address") },
                placeholder = { Text("192.168.1.123") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                supportingText = { Text("Find it using ipconfig in Windows CMD. Port 8085.") }
            )
            if (prefs.host.isNotEmpty() && !isPrivatePcAddress(prefs.host)) {
                Text("Enter a private IPv4 address (10.x.x.x, 172.16–31.x.x or 192.168.x.x).",
                    color = colors.warning, fontSize = 12.sp)
            }
            Spacer(Modifier.height(5.dp))
            Text("Libre Hardware Monitor → Options → Remote Web Server → Run. Start it with Windows and allow port 8085 on Private networks only.",
                color = colors.muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
internal fun ShawPcStatsScreen(prefs: ShawPcPreferences) {
    val colors = LocalShawPalette.current
    var snapshot by remember { mutableStateOf<ShawPcSnapshot?>(null) }
    var offline by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("Connecting…") }
    var refreshVersion by remember { mutableIntStateOf(0) }

    // Cancel network polling automatically when the tab leaves composition.
    LaunchedEffect(prefs.enabled, prefs.host, refreshVersion) {
        snapshot = null
        offline = true
        if (!prefs.enabled || !isPrivatePcAddress(prefs.host)) {
            error = "Set your PC's IPv4 address in Settings to start monitoring."
            return@LaunchedEffect
        }
        while (coroutineContext.isActive) {
            try {
                val latest = ShawPcMonitor.fetch(prefs.host)
                if (latest.stats.isEmpty()) {
                    snapshot = null
                    offline = true
                    error = "Connected, but no CPU/GPU/RAM sensors were found. Check Libre Hardware Monitor's hardware selection."
                } else {
                    snapshot = latest
                    offline = false
                    error = ""
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                snapshot = null // Never display stale data as if the PC is online.
                offline = true
                error = "PC offline. Check its IP, Libre Hardware Monitor and Private-network firewall access."
            }
            delay(2000)
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 21.dp, top = 20.dp, end = 15.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("SHAW CONTROL", color = colors.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                Text("PC Stats", color = colors.ink, fontWeight = FontWeight.SemiBold, fontSize = 30.sp)
                Spacer(Modifier.height(5.dp))
                Text(if (offline) "Offline" else "Live · ${snapshot?.computer ?: "Windows PC"}",
                    color = if (offline) colors.muted else colors.primary, fontSize = 13.sp)
            }
            IconButton(onClick = { refreshVersion++ }) {
                Icon(Icons.Outlined.Refresh, contentDescription = "Refresh PC stats", tint = colors.primary)
            }
        }
        if (offline) {
            Surface(color = colors.surface, shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().padding(18.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("PC Offline", color = colors.ink, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(error, color = colors.muted, fontSize = 13.sp, lineHeight = 19.sp)
                }
            }
        } else {
            val stats = snapshot?.stats.orEmpty()
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 30.dp)
            ) {
                items(stats, key = { it.label }) { stat ->
                    Surface(color = colors.surface, shape = RoundedCornerShape(22.dp),
                        modifier = Modifier.fillMaxWidth().height(124.dp)) {
                        Column(Modifier.fillMaxSize().padding(15.dp), verticalArrangement = Arrangement.SpaceBetween) {
                            Text(stat.label, color = colors.muted, fontSize = 12.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            Text(stat.reading, color = colors.ink, fontSize = if (stat.reading.length > 14) 16.sp else 24.sp,
                                fontWeight = FontWeight.SemiBold, maxLines = 2, lineHeight = 24.sp)
                            val fraction = stat.fraction
                            if (fraction != null) {
                                LinearProgressIndicator(progress = { fraction.coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().height(5.dp),
                                    color = colors.primary, trackColor = colors.background)
                            } else Spacer(Modifier.height(5.dp))
                        }
                    }
                }
            }
        }
    }
}
