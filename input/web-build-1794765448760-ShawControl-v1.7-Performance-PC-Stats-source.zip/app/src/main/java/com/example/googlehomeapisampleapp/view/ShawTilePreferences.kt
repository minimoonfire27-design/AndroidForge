package com.example.googlehomeapisampleapp.view

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.googlehomeapisampleapp.viewmodel.devices.DeviceViewModel
import org.json.JSONArray
import org.json.JSONObject

/** Per-device visibility, size and order; all stored locally on this phone. */
internal class ShawTilePreferences(context: Context) {
    private val store = context.applicationContext.getSharedPreferences("shaw_dashboard", Context.MODE_PRIVATE)
    var hiddenDeviceIds: Set<String> by mutableStateOf(
        store.getStringSet("hidden_device_ids_v1", emptySet())?.toSet() ?: emptySet()
    )
        private set
    var orderedIds: List<String> by mutableStateOf(readIds(store.getString("tile_order_v2", null)))
        private set
    var tileSizes: Map<String, String> by mutableStateOf(readSizes(store.getString("tile_sizes_v2", null)))
        private set

    fun isVisible(deviceId: String): Boolean = deviceId !in hiddenDeviceIds
    fun setVisible(deviceId: String, visible: Boolean) {
        val updated = if (visible) hiddenDeviceIds - deviceId else hiddenDeviceIds + deviceId
        if (updated == hiddenDeviceIds) return
        hiddenDeviceIds = updated
        store.edit().putStringSet("hidden_device_ids_v1", updated.toSet()).apply()
    }
    fun showAll() {
        hiddenDeviceIds = emptySet()
        store.edit().remove("hidden_device_ids_v1").apply()
    }
    fun sizeFor(id: String) = tileSizes[id] ?: "Medium"
    fun setSize(id: String, size: String) {
        if (size !in listOf("Small", "Medium", "Large")) return
        tileSizes = tileSizes + (id to size)
        val json = JSONObject()
        tileSizes.forEach { (key, value) -> json.put(key, value) }
        store.edit().putString("tile_sizes_v2", json.toString()).apply()
    }
    fun sort(devices: List<DeviceViewModel>): List<DeviceViewModel> {
        val order = orderedIds + devices.map { it.id }.filterNot { it in orderedIds }
        return devices.sortedBy { order.indexOf(it.id) }
    }
    fun move(id: String, direction: Int, allDevices: List<DeviceViewModel>) {
        val ids = sort(allDevices).map { it.id }.toMutableList()
        val from = ids.indexOf(id)
        if (from == -1) return
        val to = from + direction
        if (to !in ids.indices) return
        java.util.Collections.swap(ids, from, to)
        orderedIds = ids.toList()
        val json = JSONArray()
        orderedIds.forEach { json.put(it) }
        store.edit().putString("tile_order_v2", json.toString()).apply()
    }
    companion object {
        private fun readIds(value: String?): List<String> = try {
            if (value == null) emptyList() else {
                val array = JSONArray(value)
                (0 until array.length()).map { array.getString(it) }
            }
        } catch (_: Exception) { emptyList() }
        private fun readSizes(value: String?): Map<String, String> = try {
            if (value == null) emptyMap() else {
                val obj = JSONObject(value)
                obj.keys().asSequence().associateWith { obj.getString(it) }
            }
        } catch (_: Exception) { emptyMap() }
    }
}
