# Shaw Control v1.5 — Personalise Home

Android package: `uk.co.shawcontrol.home` | version `1.5.0-custom-home` | versionCode `6`.

## What changed

1. **Quiet, responsive status:** A successful Home API command shows its requested On/Off state instead of leaving the main tile labelled "Waiting for Google". A short "Changing…" indicator only appears if the network call takes longer than 1.2 seconds. A warning appears only for an actual request timeout/error or failed manual Sync — not just for a late cached Google update. The app does NOT claim a displayed request is necessarily a verified physical state. No automatic power retries.
2. **Theme settings:** Settings → Appearance → System / Light / Dark. This follows the phone's mode when System is selected.
3. **Accent colours:** Blue, Violet, Teal, Green or Coral.
4. **Backgrounds:** Default, Slate, Sand, Sage or Rose. Each preset has light and dark variants.
5. **Per-device tile sizes:** Small, Medium or Large. Large spans both columns.
6. **Tile position:** Settings → Home tiles → move-up / move-down arrows to reorder devices in Home. This is deliberate order editing, NOT drag-and-drop positioning.
7. **Saved preferences:** Theme, colour, background, visibility, size and order persist locally using SharedPreferences; no change to Google Home permissions.
8. **Safety:** PC power-off confirmation and the working v1.3 queued reverse command handling remain.

## Build / install

This ZIP is an Android *source project*, not an APK. Build it privately, as it contains Google's separately distributed Home SDK Maven artifacts. Don't upload those SDK artifacts to a public GitHub repository. No native Gradle/Android build was possible in the author's environment; this project has NOT been tested on your Samsung yet. Test before uninstalling an existing working build.

**AndroidForge has used different certificates per previous build.** New APK signing may stop `adb install -r` with `INSTALL_FAILED_UPDATE_INCOMPATIBLE`, and may require a matching SHA-1 Android OAuth registration. Inspect the **exact new APK** before changing Google Cloud settings. Don't assume an older version's fingerprint is valid.

On your Windows PC, after replacing `<NEW-FILE>.apk` with the actual downloaded filename:

    "C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" install -r "%USERPROFILE%\Downloads\<NEW-FILE>.apk"

Start the app:

    "C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" shell monkey -p uk.co.shawcontrol.home 1

## Error log commands (every version)

Clear immediately *before* reproducing an error:

    "C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -c

Save immediately after the error:

    "C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -d -v time > "%USERPROFILE%\Desktop\shaw-error.txt"

If the event disappears from the buffer, capture *live* before triggering it, stop with Ctrl+C:

    "C:\Users\minim\Desktop\Fire Tablet\platform-tools-latest-windows\platform-tools\adb.exe" logcat -v time > "%USERPROFILE%\Desktop\shaw-live-error.txt"

Logs may contain personal details; don't post raw logs publicly.

## Smoke test

- Confirm that your existing Google Home account still loads devices.
- Tap Jamie's Light ON, then OFF. The tile should say On/Off immediately without "Waiting for Google" in the normal success case.
- Settings → Dark, Violet, Sage: colours should change instantly. Close/reopen to confirm saved.
- Resize Desk to Large: its tile should span both columns.
- Move Desk above Jamie's Light and verify Home order updates. Hide a tile; it should disappear without disconnecting Google Home.
- Tap the PC plug when switching OFF to confirm the safety dialog still appears. Do not cut a running PC's power.

## Optional future PC stats — NOT included in v1.5

A lightweight Windows sensor server (e.g. Libre Hardware Monitor's remote web interface) could share CPU, GPU, RAM and temperature data with a future Shaw Control PC Stats screen over local Wi-Fi. No spacedesk or remote desktop required. Keep the server LAN-only, ideally with authentication; never expose it directly to the public internet.

## Validation

- Kotlin parser sanity check on modified Kotlin files (no syntax parser errors; Android / Compose dependencies unavailable in the container).
- Eight pure Kotlin state-reconciliation tests passed.
- Project has not had a full Android Gradle build or device runtime test here.
