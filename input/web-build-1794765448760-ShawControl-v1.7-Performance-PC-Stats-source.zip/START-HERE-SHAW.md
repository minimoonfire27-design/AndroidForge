# CURRENT VERSION: Shaw Control v1.6 — Smooth & Fast

**Start with `README-V1.6-FIRST.md`** for the changes, how to restore default Android animations, build/install steps, and error-log commands.

---

# Shaw Control v1.3 — fast reverse Google Home edition (experimental)

This is a **real Home APIs integration source project**, adapted from Google's official Android Home API sample. It requests Google Home permissions, loads actual Google Home structures/devices, displays device cards, and sends OnOff / brightness commands for supported devices. There are **no embedded passwords**, no Tuya/Tapo credentials, and no shortcut pretending to sign in.

## Before building

1. In Google Cloud, keep **Shaw Control** OAuth app in Testing and your Google account as a test user.
2. Create an **OAuth Web client** for this Google Cloud project and put its Client ID into `local.properties` as `WEB_CLIENT_ID_DEV=...` (or set it as the `WEB_CLIENT_ID_DEV` Gradle project property). Don't put a client secret inside the app.
3. Create an **OAuth Android client** with package name `uk.co.shawcontrol.home` AND the SHA-1 fingerprint of the exact APK's signing key. They must match. Debug APKs signed with different keys need different Android clients.
4. Keep the Google Home SDK artifacts in `home-sdk-repo/`, already included from the SDK ZIP you supplied. These are solely for your private developer build. Do not publish this ZIP or proprietary SDK contents to a public repository.
5. Build with a current Android Studio / Java 17 / Android SDK 36. The official sample needs AGP 8.13.2 and Kotlin 2.4.0. AndroidForge may not support this recent toolchain, and would need access to the private SDK repo.

## What happens inside the app

First launch: **Connect Google Home** -> account selection -> Google Home permission/structure consent. Once granted: devices from the selected Google Home structure appear, with switches for devices exposing `OnOff` and slider for devices exposing `LevelControl` (e.g. lights). Tap a card's name for Google's fuller device controls. The PC plug has an extra off confirmation based on a case-insensitive `pc` in its displayed name; rename that plug accordingly. Use the **Access** button to re-authorise your home.

## Limitations / testing

* Not compiled or tested against your Galaxy A13 or your Tapo/Tuya devices in this environment.
* Google Home app visibility **does not guarantee** a third-party app can discover/control each device: permission, platform scope and supported traits still matter.
* The OAuth Web client ID must be set before relying on the one-button account selection. The fallback “Already signed in? Grant access” requests the official SDK permission flow.
* The official sample and underlying functionality are Apache 2.0 (see LICENSE); modifications are a private experimental adaptation.
* The Google Home SDK library files are proprietary and should remain private; don't commit them to a public GitHub repo.
* Don't publish builds or share their signing keys. Use a persistent private signing key for updates, otherwise install via uninstall and reauthorise.
* No direct PC stats in this edition; this version focuses on real Google Home devices only.


## v1.3 quick test

1. Install the built APK and ensure Google Home authorisation is granted. If login fails,
   check Android OAuth SHA-1 for that **exact** APK; AndroidForge has previously rotated
   certificates on every build.
2. On a safe device such as the light, tap ON; the switch shows requested ON immediately.
3. Before the Google state changes, tap OFF. OFF is allowed/queued and should NOT wait
   for Google's 10-second state confirmation. Look for "Queued OFF" if the prior RPC is
   still executing.
4. Check the visible Home API response duration to distinguish slow command transport
   from slow state reporting. Look at logcat tag `ShawControl.Commands` for timing.
5. If unsure, use "Refresh Google's state" (it reads, never sends another power command).

The switch can show your most recent requested setting when Google Home is late; this is
explicitly labelled *unconfirmed* and should not be mistaken for verified power state.
Never test PC plug OFF while Windows is running.
