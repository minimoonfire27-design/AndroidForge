# Shaw Control v1.6.2 — second Kotlin build fix

AndroidForge error: `:app:compileDebugKotlin` failed with *Platform declaration clash*: both declarations generated the JVM method `setKeepScreenAwake(Z)V` in `ShawAppearancePreferences` (lines 24 and 36 of `ShawAppearance.kt`).

**Fixed:** `var keepScreenAwake by mutableStateOf(...)` automatically produces a property setter named `setKeepScreenAwake(boolean)` even when it is declared with `private set`. The separately declared `fun setKeepScreenAwake(Boolean)` had the **same JVM signature**. Renamed the explicit method to `updateKeepScreenAwake(Boolean)` and updated the `onCheckedChange` callback in `ShawHomeView.kt`. The preference key (`keep_screen_awake_v16`) and behaviour are unchanged.

**Also retained:** v1.6.1's prior two fixes for the duplicate `.value.value` access at `ShawHomeView.kt` lines 542 and 703.

**Verification:** Compiled the actual updated `ShawAppearance.kt` with local lightweight Compose/Android stubs and inspected JVM bytecode to confirm unique setters; all eight existing standalone state-reconciliation checks passed. A complete Android Gradle/Google Home build **has not been run** in this environment, so final success must be confirmed in AndroidForge.

**Version:** `versionCode = 8`, `versionName = "1.6.2-kotlin-fix"`, app ID still `uk.co.shawcontrol.home`.

## Build

Upload this entire ZIP to AndroidForge. Keep the Google Home SDK binaries private (do not commit to a public repository). If it fails again, share the first `e: file:///...` Kotlin error lines or the `AndroidForge-logs` build artifact. Do not uninstall the working version while the new APK hasn't built.

After a successful APK build, use the **actual** downloaded filename for ADB, and check the new APK's signing fingerprint for OAuth since AndroidForge has changed keys across previous builds. The normal install/logging commands remain in `README-V1.6-FIRST.md`.
