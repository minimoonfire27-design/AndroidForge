package com.example.googlehomeapisampleapp.view

import android.content.Intent
import android.util.Log
import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.googlehomeapisampleapp.AccountSwitchProxyActivity
import com.example.googlehomeapisampleapp.viewmodel.HomeAppViewModel
import com.example.googlehomeapisampleapp.viewmodel.devices.DeviceViewModel
import com.google.home.matter.standard.OnOff
import com.google.home.matter.standard.LevelControl
import com.google.home.matter.standard.LevelControlTrait
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull

private val Night = Color(0xFF0B1422)
private val Panel = Color(0xFF17253A)
private val Sky = Color(0xFF72B6FF)
private val Pale = Color(0xFFB0C1D7)

@Composable
fun ShawHomeView(vm: HomeAppViewModel) {
    val signedIn by vm.homeApp.permissionsManager.isSignedIn.collectAsState()
    val structure by vm.selectedStructureVM.collectAsState()
    val selectedDevice by vm.selectedDeviceVM.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        vm.navigateToProxyActivity.collect {
            val intent = Intent(context, AccountSwitchProxyActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            context.startActivity(intent)
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Sky, background = Night, surface = Panel)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Night) {
            if (!signedIn) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(26.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Shaw Control", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(10.dp))
                    Text("Your home, one connection.", fontSize = 16.sp, color = Pale)
                    Spacer(Modifier.height(40.dp))
                    Button(
                        onClick = { vm.signInWithGoogleAccount(context) },
                        modifier = Modifier.fillMaxWidth().height(58.dp)
                    ) { Text("Connect Google Home", fontSize = 17.sp) }
                    Spacer(Modifier.height(12.dp))
                    TextButton(onClick = { vm.homeApp.permissionsManager.requestPermissions() }) {
                        Text("Already signed in? Grant access")
                    }
                    Spacer(Modifier.height(15.dp))
                    Text("Google will ask which home and devices to share. Your password stays with Google.",
                        fontSize = 13.sp, color = Pale)
                }
            } else if (selectedDevice != null) {
                // Retain Google's real device-detail controls, including supported traits.
                com.example.googlehomeapisampleapp.view.devices.DeviceView(vm)
            } else {
                val selectedRooms = structure?.roomVMs?.collectAsState()?.value.orEmpty()
                val unassigned = structure?.deviceVMsWithoutRooms?.collectAsState()?.value.orEmpty()
                Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    Spacer(Modifier.height(37.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Shaw Control", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            Text(structure?.name ?: "Loading your Google Home…", color = Pale, fontSize = 14.sp)
                        }
                        TextButton(onClick = { vm.homeApp.permissionsManager.requestPermissions(isForceRefresh = true) }) {
                            Text("Access")
                        }
                    }
                    Spacer(Modifier.height(19.dp))
                    Column(Modifier.verticalScroll(rememberScrollState()).fillMaxWidth()) {
                        if (structure == null) {
                            Text("Your home is loading. Check your Google Home permissions if no devices appear.", color = Pale)
                        }
                        selectedRooms.forEach { room ->
                            Text(room.name.collectAsState().value, color = Pale,
                                modifier = Modifier.padding(top = 17.dp, bottom = 7.dp, start = 4.dp))
                            room.deviceVMs.collectAsState().value.forEach { device ->
                                key(device.id) {
                                    ShawDeviceCard(device) { scope.launch { vm.selectedDeviceVM.emit(device) } }
                                }
                            }
                        }
                        if (unassigned.isNotEmpty()) {
                            Text("Other devices", color = Pale, modifier = Modifier.padding(top = 17.dp, bottom = 7.dp))
                            unassigned.forEach { device ->
                                key(device.id) {
                                    ShawDeviceCard(device) { scope.launch { vm.selectedDeviceVM.emit(device) } }
                                }
                            }
                        }
                        Spacer(Modifier.height(25.dp))
                        Text("Controls are synced through Google's Home APIs. Some device types may not expose every feature.",
                            fontSize = 12.sp, color = Pale)
                        Spacer(Modifier.height(30.dp))
                    }
                }
            }
        }
    }
}

/**
 * The Google Home SDK's cloud trait values may lag behind a successful command.
 * IMPORTANT: never let an old reported value overwrite the user's latest request,
 * and never block the OFF switch waiting for a trait event that may not arrive.
 *
 * ON/OFF commands are explicit, not toggle(): turning OFF after an unconfirmed ON
 * therefore still sends OFF, even if the cloud continues to report OFF.
 *
 * No automatic command retries, particularly for the PC power plug.
 */
@Composable
private fun ShawDeviceCard(vm: DeviceViewModel, onOpen: () -> Unit) {
    val name by vm.name.collectAsState()
    val status by vm.status.collectAsState()
    val traits by vm.traits.collectAsState()
    val powerReading by vm.powerReading.collectAsState()
    val brightnessReading by vm.brightnessReading.collectAsState()
    val scope = rememberCoroutineScope()

    val onOff = traits.filterIsInstance<OnOff>().firstOrNull()
    val level = traits.filterIsInstance<LevelControl>().firstOrNull()
    val reportedOn = powerReading.value
    val reportedLevel = brightnessReading.value

    // The command's *requested* state is independent of Google Home's last cached report.
    // It is NOT described as verified until the trait stream reports a NEW matching state.
    var requestedOn by remember(vm.id) { mutableStateOf<Boolean?>(null) }
    var revisionBeforeCommand by remember(vm.id) { mutableLongStateOf(0L) }
    var sendingPower by remember(vm.id) { mutableStateOf(false) }
    // Last explicit user action while a previous API command is in flight.
    // Queuing the reverse action avoids sending two racing network commands.
    var queuedPower by remember(vm.id) { mutableStateOf<Boolean?>(null) }
    var commandNumber by remember(vm.id) { mutableIntStateOf(0) }
    var lastPowerApiDurationMs by remember(vm.id) { mutableStateOf<Long?>(null) }
    var powerMessage by remember(vm.id) { mutableStateOf<String?>(null) }
    var confirmPcOff by remember(vm.id) { mutableStateOf(false) }
    var syncingState by remember(vm.id) { mutableStateOf(false) }

    var brightness by remember(vm.id) { mutableFloatStateOf(reportedLevel?.toFloat() ?: 0f) }
    var editingBrightness by remember(vm.id) { mutableStateOf(false) }
    var sendingBrightness by remember(vm.id) { mutableStateOf(false) }
    var requestedLevel by remember(vm.id) { mutableStateOf<Int?>(null) }
    var brightnessRevisionBeforeCommand by remember(vm.id) { mutableLongStateOf(0L) }
    var brightnessCommandNumber by remember(vm.id) { mutableIntStateOf(0) }
    var brightnessMessage by remember(vm.id) { mutableStateOf<String?>(null) }

    val effectiveOn = requestedOn ?: reportedOn ?: false
    val isPcPlug = remember(name) { Regex("(?i)\\b(pc|computer)\\b").containsMatchIn(name) }

    // Only a fresh transition to the requested state counts as confirmation. A cached
    // Google OFF value cannot 'confirm' a freshly requested OFF if it was already OFF.
    LaunchedEffect(powerReading, requestedOn) {
        if (queuedPower == null && ShawStateReconciler.isConfirmed(
                requestedOn, revisionBeforeCommand, powerReading.value, powerReading.revision
            )) {
            Log.i("ShawControl.Commands", "Power state confirmed by trait flow for ${vm.id}")
            requestedOn = null
            powerMessage = null
        }
    }

    // Notify after a delay; keep the user's selected state and allow reversing it.
    LaunchedEffect(commandNumber) {
        if (commandNumber > 0) {
            val thisCommand = commandNumber
            delay(10000)
            if (commandNumber == thisCommand && requestedOn != null) {
                powerMessage = "Google still hasn't confirmed this change. The switch shows " +
                    "your last request, not a verified device state. You can reverse it below."
            }
        }
    }

    LaunchedEffect(brightnessReading, requestedLevel) {
        if (ShawStateReconciler.isConfirmedWithinOne(
                requestedLevel, brightnessRevisionBeforeCommand,
                reportedLevel, brightnessReading.revision
            )) {
            requestedLevel = null
            brightnessMessage = null
        }
        if (!editingBrightness && requestedLevel == null && reportedLevel != null) {
            brightness = reportedLevel.toFloat()
        }
    }
    LaunchedEffect(brightnessCommandNumber) {
        if (brightnessCommandNumber > 0) {
            val thisCommand = brightnessCommandNumber
            delay(10000)
            if (brightnessCommandNumber == thisCommand && requestedLevel != null) {
                brightnessMessage = "Brightness hasn't been confirmed by Google. " +
                    "Showing your last request."
            }
        }
    }

    fun refreshState() {
        if (syncingState || sendingPower || sendingBrightness) return
        syncingState = true
        scope.launch {
            try {
                // Force reads may be throttled; keep them manual and bounded.
                val completed = withTimeoutOrNull(4500) {
                    if (onOff != null) onOff.forceRead()
                    if (level != null) level.forceRead()
                    true
                } ?: false
                if (!completed) {
                    powerMessage = "State refresh timed out. Google's last report may be old."
                } else if (requestedOn != null) {
                    powerMessage = "Refresh requested. Waiting for a new Google Home state update."
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                powerMessage = "State refresh failed: ${e.message?.take(100) ?: "Device unavailable"}"
            } finally {
                syncingState = false
            }
        }
    }

    fun setPower(next: Boolean, dispatchQueued: Boolean = false) {
        if (onOff == null || (!dispatchQueued && effectiveOn == next)) return
        if (sendingPower) {
            // This is a NEW user tap, not an automated retry. Queue just the latest
            // requested state until the in-flight command finishes, preserving order.
            queuedPower = next
            requestedOn = next
            powerMessage = "Queued ${if (next) "ON" else "OFF"} — waiting for the previous command to finish."
            Log.i("ShawControl.Commands", "Queued user reversal for ${vm.id}: $next")
            return
        }
        // Snapshot the revision BEFORE beginning a new request.
        revisionBeforeCommand = powerReading.revision
        requestedOn = next
        commandNumber++
        sendingPower = true
        powerMessage = null
        val currentCommand = commandNumber
        lastPowerApiDurationMs = null
        val startedAt = SystemClock.elapsedRealtime()
        Log.i("ShawControl.Commands", "Power request for ${vm.id}: $next, lastReported=$reportedOn")
        scope.launch {
            try {
                // A hanging cloud RPC must not block the switch forever.
                val accepted = withTimeoutOrNull(8000) {
                    if (next) onOff.on() else onOff.off()
                    true
                } ?: false
                if (commandNumber == currentCommand) {
                    if (!accepted) {
                        powerMessage = "Google took too long to respond; the physical state is " +
                            "uncertain. No command was retried."
                        Log.w("ShawControl.Commands", "Power command response timed out for ${vm.id}")
                    } else {
                        Log.i("ShawControl.Commands", "Power command response for ${vm.id} after ${SystemClock.elapsedRealtime() - startedAt} ms")
                        // If a reverse command is queued, skip this read; the queued
                        // command will run next and eventually read the final state.
                        if (queuedPower != null) return@launch
                        // Don't make the entire card wait for forceRead(). Trigger exactly
                        // one low-priority targeted read; live state comes from the flow.
                        scope.launch {
                            delay(500)
                            try {
                                withTimeoutOrNull(3500) { onOff.forceRead() }
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                Log.w("ShawControl.Commands", "Post-command read unavailable", e)
                            }
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("ShawControl.Commands", "Power command exception for ${vm.id}", e)
                if (commandNumber == currentCommand) {
                    powerMessage = "Google reported an error: " +
                        "${e.message?.take(130) ?: "Device unavailable"}. Check the light's real state."
                }
            } finally {
                // Crucial: release the control when the COMMAND returns, not when
                // Google's delayed trait cache catches up (which may never happen).
                lastPowerApiDurationMs = SystemClock.elapsedRealtime() - startedAt
                sendingPower = false
                // Dispatch the user's latest queued instruction once, in sequence.
                // Never auto-repeat the old ON/OFF instruction.
                val queued = queuedPower
                queuedPower = null
                if (queued != null && queued != next) {
                    setPower(queued, dispatchQueued = true)
                }
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable(onClick = onOpen)) {
                    Text(name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        when {
                            sendingPower && queuedPower != null -> "Queued ${if (queuedPower == true) "ON" else "OFF"} after current command…"
                            sendingPower -> "Sending command…"
                            requestedOn != null -> "Requested ${if (requestedOn == true) "ON" else "OFF"} · unconfirmed"
                            reportedOn != null -> "Google reports ${if (reportedOn) "ON" else "OFF"}"
                            else -> status
                        },
                        color = if (requestedOn != null) Sky else Pale, fontSize = 12.sp
                    )
                }
                if (onOff != null) {
                    if (sendingPower) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Sky
                        )
                        Spacer(Modifier.width(12.dp))
                    }
                    Switch(
                        checked = effectiveOn,
                        onCheckedChange = { next ->
                            if (!next && isPcPlug) confirmPcOff = true
                            else setPower(next)
                        },
                        // Accept a reverse tap immediately. While an API call is in
                        // flight, the requested opposite state is queued (not raced).
                        enabled = true
                    )
                } else {
                    Text("Details", color = Sky, modifier = Modifier.clickable(onClick = onOpen))
                }
            }
            if (requestedOn != null) {
                Spacer(Modifier.height(7.dp))
                Text(
                    "Google last reported: ${reportedOn?.let { if (it) "ON" else "OFF" } ?: "unknown"}. " +
                        "Control shows your latest request until a fresh update arrives.",
                    color = Pale, fontSize = 12.sp
                )
            }
            if (powerMessage != null) {
                Spacer(Modifier.height(7.dp))
                Text(powerMessage ?: "", color = Color(0xFFFFB0A4), fontSize = 12.sp)
            }
            if (level != null && reportedLevel != null) {
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Brightness ${(brightness * 100f / 254f).toInt()}%" +
                            (if (requestedLevel != null) " · unconfirmed" else ""),
                        color = Pale, fontSize = 13.sp
                    )
                    Spacer(Modifier.weight(1f))
                    if (sendingBrightness) Text("Sending…", color = Sky, fontSize = 12.sp)
                }
                Slider(
                    value = brightness.coerceIn(0f, 254f),
                    onValueChange = { brightness = it; editingBrightness = true },
                    valueRange = 0f..254f,
                    enabled = !sendingBrightness,
                    onValueChangeFinished = {
                        editingBrightness = false
                        val chosen = brightness.toInt().coerceIn(0, 254)
                        val oldDisplayed = requestedLevel ?: reportedLevel
                        if (!sendingBrightness && chosen != oldDisplayed) {
                            sendingBrightness = true
                            brightnessRevisionBeforeCommand = brightnessReading.revision
                            requestedLevel = chosen
                            brightnessCommandNumber++
                            brightnessMessage = null
                            val command = brightnessCommandNumber
                            scope.launch {
                                try {
                                    val accepted = withTimeoutOrNull(8000) {
                                        level.moveToLevelWithOnOff(
                                            level = chosen.toUByte(), transitionTime = null,
                                            optionsMask = LevelControlTrait.OptionsBitmap(),
                                            optionsOverride = LevelControlTrait.OptionsBitmap()
                                        )
                                        true
                                    } ?: false
                                    if (!accepted && command == brightnessCommandNumber) {
                                        brightnessMessage = "Brightness command timed out. " +
                                            "It might still take effect; it was not retried."
                                    }
                                    if (accepted) {
                                        scope.launch {
                                            delay(500)
                                            try {
                                                withTimeoutOrNull(3500) { level.forceRead() }
                                            } catch (e: CancellationException) {
                                                throw e
                                            } catch (e: Exception) {
                                                Log.w("ShawControl.Commands", "Brightness read unavailable", e)
                                            }
                                        }
                                    }
                                } catch (e: CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    brightnessMessage = "Brightness failed: ${e.message?.take(100) ?: "Device unavailable"}"
                                } finally {
                                    sendingBrightness = false
                                }
                            }
                        }
                    }
                )
                if (brightnessMessage != null) {
                    Text(brightnessMessage ?: "", color = Color(0xFFFFB0A4), fontSize = 12.sp)
                }
            }
            if (lastPowerApiDurationMs != null) {
                Text("Home API response: ${lastPowerApiDurationMs} ms (not device confirmation)",
                    color = Pale, fontSize = 11.sp)
            }
            if (onOff != null || level != null) {
                TextButton(onClick = { refreshState() }, enabled = !syncingState && !sendingPower && !sendingBrightness) {
                    Text(if (syncingState) "Refreshing…" else "Refresh Google's state", fontSize = 12.sp)
                }
            }
        }
    }

    if (confirmPcOff) {
        AlertDialog(
            onDismissRequest = { confirmPcOff = false },
            title = { Text("Switch off PC plug?") },
            text = { Text("This immediately cuts electricity. Shut Windows down first. The app will not retry this command automatically.") },
            confirmButton = {
                TextButton(onClick = { confirmPcOff = false; setPower(false) }) { Text("Switch off") }
            },
            dismissButton = { TextButton(onClick = { confirmPcOff = false }) { Text("Cancel") } }
        )
    }
}
