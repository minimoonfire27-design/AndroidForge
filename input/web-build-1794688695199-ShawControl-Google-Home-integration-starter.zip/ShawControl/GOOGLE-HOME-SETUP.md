# Shaw Control — Google Home integration preparation

## STATUS: NOT YET CONNECTED TO THE GOOGLE HOME APIs

This archive preserves the existing Shaw Control Android Java application and adds developer integration documentation. It is NOT a Google Home-controlled replacement, and the existing Tapo/Tuya connection implementations have not been removed. The app does not yet read, list or command Google Home devices. Do not grant it Google credentials through custom fields.

A fully functioning one-button Google Home setup cannot be produced by renaming a source zip or putting a Google Home shortcut in the app.

## Official, supported implementation route

1. Sign in to Google Home Developers, download the Android **Home APIs SDK** (it is distributed separately; this archive does not contain it): https://developers.home.google.com/apis/android/sdk
2. Start from Google's reference Android sample: https://github.com/google-home/google-home-api-sample-app-android and https://developers.home.google.com/apis/android/sample-app/build
3. Configure OAuth in Google Cloud for the exact app package AND the certificate fingerprint of the actual signing key. Use the `home.platform.selected.devices` / `HOME_PLATFORM_SCOPE_VERSION_1` scope unless approved for wider access. Do not embed private credentials in this ZIP.
4. Add Google's SDK AAR files and repository as per their current documentation. AndroidForge may not have access to those private/local SDK artifacts: verify the build service supports your SDK dependency setup before uploading.
5. In an Android/Kotlin HomeClient-backed layer, request the Google Home Permissions API. After user consent, use the Device API to enumerate the selected devices in their home. Match **Desk**, **PC** and **Jamie's Light** by actual discovered names/IDs (never fake devices).
6. Observe the OnOff trait for Tapo plugs and Jamie's Light; invoke on/off trait commands. Where exposed, observe LevelControl for brightness and send level commands; gracefully handle unsupported traits or unavailable devices. The Home APIs don't guarantee a device visible in Google Home is exposed to third-party applications.
7. For the **PC plug**, retain the explicit warning and confirmation *before turning OFF*. Do not automatically retry a power command after an ambiguous timeout. Treat successful API calls and actual device state separately.
8. Keep the granted Home structure/device selection and account via Google's SDK; do not save a Google password in app settings.
9. Test with the user's real Galaxy A13 (Android 14) and supported Google Home devices, then build a signed APK. Do not claim functionality on simulated or untested devices.

Google Docs:
- https://developers.home.google.com/apis/android/get-started
- https://developers.home.google.com/apis/android/device
- https://developers.home.google.com/apis/android/sample-app/build
- https://developers.home.google.com/apis/android/onboarding-guidance

## Why not just open the Google Home app?

Launching `com.google.android.apps.chromecast.app` only opens an app. It does not return OAuth consent, a device list, or control tokens to Shaw Control. The actual Google Home SDK and OAuth configuration are required.

## Existing functionality

The included v0.9 source retains its previously implemented direct Tapo and optional Tuya logic. It has not been tested with the user's devices in this archive. The proprietary Google Home SDK binaries are intentionally not included.
