# Shaw Control 1.7.1 — AndroidForge Kotlin build fix

## What failed in 1.7.0

All three uploaded AndroidForge logs (`build-1794765592-2.log`, `build-1794765675-2.log`, and `build-1794765824-2.log`) report only the following Kotlin compilation errors:

- `ShawPcMonitor.kt:37` and `:41`: `setEnabled(Z)V` JVM signature clash.
- `ShawPcMonitor.kt:39` and `:45`: `setHost(Ljava/lang/String;)V` JVM signature clash.

The `ShawPcPreferences` properties `var enabled` and `var host` compile to JVM setters named `setEnabled` and `setHost`. Declaring explicit functions with the same name and argument types caused the errors.

## Changes in 1.7.1

- Renamed `fun setEnabled(...)` -> `fun updateMonitoringEnabled(...)`.
- Renamed `fun setHost(...)` -> `fun updatePcHost(...)`.
- Updated both function references in the PC monitoring Settings screen.
- Incremented `versionCode` to `10` and `versionName` to `1.7.1-pc-stats-kotlin-fix`.
- Added a Kotlin property/function collision scanner: `tools/tests/check_kotlin_property_collisions.py`.

No change to Google Home logic, HTTP port, or PC stats display.

## Validation actually completed

- Checked all 3 uploaded AndroidForge compilation logs. No other Kotlin compilation errors are present in those logs.
- Compiled the *actual* `ShawPcPreferences` code with `kotlinc-jvm` and minimal Android/Compose stubs. Confirmed settings writes/reads, callback function references, and no JVM method collisions.
- Scanned 124 Kotlin files (113 class bodies) for matching mutable-property/JVM-setter collisions: passed.
- Compiled and ran the original 8 state-sync Kotlin tests: passed.
- Verified ZIP files and Android project layout before sharing.

**Limit:** This development environment does not include the Android SDK/Gradle dependency cache needed to run `:app:compileDebugKotlin` or produce an APK. Only AndroidForge can confirm the complete Android project build. Please share the complete `AndroidForge-logs.zip` if there is a subsequent error.

## Build and device setup

1. Keep your existing working Shaw Control installed while building.
2. Upload `ShawControl-v1.7.1-PC-Stats-Compiler-Fix-source.zip` privately into AndroidForge.
3. Build an APK. If it succeeds, verify its actual signing certificate SHA-1 before editing the Google Cloud Android OAuth registration.
4. Don't blindly uninstall the existing app: a signing-key mismatch would erase locally saved settings.

For PC Stats to work, Libre Hardware Monitor needs **Options > Remote Web Server > Run**, port **8085**, and local Windows Firewall access. Enter the Windows PC's private IPv4 address in Shaw Control Settings. This app only polls while the PC Stats tab is open.
