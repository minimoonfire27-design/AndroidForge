"""Guard against JVM signature collisions between mutable Kotlin properties and setX() functions.

Run: python3 tools/tests/check_kotlin_property_collisions.py
This is a project-wide static guard, not a substitute for Gradle's Kotlin compiler.
"""
from pathlib import Path
import re

SRC = Path(__file__).resolve().parents[2] / 'app' / 'src' / 'main' / 'java'
DECL = re.compile(r'\b(?:data\s+|sealed\s+|abstract\s+|internal\s+|private\s+|public\s+|open\s+)*class\s+(\w+)\b')
VAR = re.compile(r'(?<!private )\bvar\s+(\w+)\s*(?:[:=]|\bby\b)')
FUN = re.compile(r'\bfun\s+(set[A-Z]\w*)\s*\(')
errors = []
classes_scanned = 0
files_scanned = 0
for path in sorted(SRC.rglob('*.kt')):
    files_scanned += 1
    src = path.read_text(encoding='utf-8')
    # Remove comments and string literals to avoid counting irrelevant braces/declarations.
    stripped = re.sub(r'/\*.*?\*/|//[^\n]*|""".*?"""|"(?:\\.|[^"\\])*"', ' ', src, flags=re.S)
    for match in DECL.finditer(stripped):
        opening = stripped.find('{', match.end())
        # Skip class declarations without a body; ignore a nearby following class.
        if opening < 0 or 'class ' in stripped[match.end():opening] or opening - match.end() > 450:
            continue
        depth = 0
        closing = -1
        for j in range(opening, len(stripped)):
            if stripped[j] == '{': depth += 1
            elif stripped[j] == '}':
                depth -= 1
                if depth == 0:
                    closing = j
                    break
        if closing < 0:
            continue
        classes_scanned += 1
        block = stripped[opening:closing + 1]
        # Private backing-field vars typically do not generate a public JVM setter.
        # Check public/internal/protected vars and vars with a `private set` instead.
        mutable = {m.group(1) for m in VAR.finditer(block)}
        funcs = {m.group(1) for m in FUN.finditer(block)}
        for name in mutable:
            setter = 'set' + name[0].upper() + name[1:]
            if setter in funcs:
                errors.append(f'{path.relative_to(SRC)}:{match.group(1)}: var {name} conflicts with fun {setter}()')

if errors:
    print('FAILED: JVM setter naming conflicts found:\n' + '\n'.join(errors))
    raise SystemExit(1)
print(f'PASS: checked {files_scanned} Kotlin files, {classes_scanned} class bodies; no setter-name clashes found')
